﻿using System;

namespace BankManagementApp
{
    public class BankAccount
    {
        public string Owner { get; set; }
        public string AccountNumber { get; private set; }
        public decimal Balance { get; private set; }

        public BankAccount(string owner, decimal initialBalance)
        {
            if (initialBalance < 0)
            {
                throw new ArgumentException(
                    "Initial balance cannot be negative.");
            }

            Owner = owner;
            AccountNumber =
                Random.Shared.Next(100000, 1000000).ToString();

            Balance = initialBalance;
        }

        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException(
                    "Deposit must be greater than zero.");
            }

            Balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException(
                    "Withdrawal must be greater than zero.");
            }

            if (amount > Balance)
            {
                throw new InvalidOperationException(
                    "Insufficient balance. You cannot withdraw " +
                    "more than the available balance.");
            }

            Balance -= amount;
        }
    }
}