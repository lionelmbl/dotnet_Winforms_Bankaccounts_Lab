﻿namespace BankManagementApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            lbTitle = new Label();
            lbOwner = new Label();
            txtOwner = new TextBox();
            lblInitialAmount = new Label();
            txtAmount = new TextBox();
            btnCreate = new Button();
            dgvAccounts = new DataGridView();
            lblTransaction = new Label();
            txtTransaction = new TextBox();
            btnDeposit = new Button();
            btnWithdraw = new Button();

            ((System.ComponentModel.ISupportInitialize)dgvAccounts).BeginInit();
            SuspendLayout();

            // lbTitle
            lbTitle.BackColor = SystemColors.ControlDarkDark;
            lbTitle.Font = new System.Drawing.Font(
                "Segoe UI", 20F, FontStyle.Bold);
            lbTitle.ForeColor = SystemColors.Control;
            lbTitle.Location = new Point(30, 20);
            lbTitle.Name = "lbTitle";
            lbTitle.Size = new Size(920, 45);
            lbTitle.TabIndex = 0;
            lbTitle.Text = "NGASKA FIRST BANK";
            lbTitle.TextAlign = ContentAlignment.MiddleCenter;

            // lbOwner
            lbOwner.AutoSize = true;
            lbOwner.Location = new Point(30, 85);
            lbOwner.Name = "lbOwner";
            lbOwner.Size = new Size(107, 20);
            lbOwner.TabIndex = 1;
            lbOwner.Text = "Owner Name:";

            // txtOwner
            txtOwner.Location = new Point(190, 82);
            txtOwner.Name = "txtOwner";
            txtOwner.Size = new Size(280, 27);
            txtOwner.TabIndex = 2;

            // lblInitialAmount
            lblInitialAmount.AutoSize = true;
            lblInitialAmount.Location = new Point(30, 125);
            lblInitialAmount.Name = "lblInitialAmount";
            lblInitialAmount.Size = new Size(156, 20);
            lblInitialAmount.TabIndex = 3;
            lblInitialAmount.Text = "Initial Amount (FCFA):";

            // txtAmount
            txtAmount.Location = new Point(190, 122);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(280, 27);
            txtAmount.TabIndex = 4;

            // btnCreate
            btnCreate.Location = new Point(500, 95);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(180, 45);
            btnCreate.TabIndex = 5;
            btnCreate.Text = "Create Account";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;

            // dgvAccounts
            dgvAccounts.AllowUserToAddRows = false;
            dgvAccounts.AutoGenerateColumns = true;
            dgvAccounts.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;
            dgvAccounts.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAccounts.Location = new Point(30, 180);
            dgvAccounts.MultiSelect = false;
            dgvAccounts.Name = "dgvAccounts";
            dgvAccounts.ReadOnly = true;
            dgvAccounts.RowHeadersWidth = 51;
            dgvAccounts.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dgvAccounts.Size = new Size(920, 280);
            dgvAccounts.TabIndex = 6;

            // lblTransaction
            lblTransaction.AutoSize = true;
            lblTransaction.Location = new Point(30, 490);
            lblTransaction.Name = "lblTransaction";
            lblTransaction.Size = new Size(200, 20);
            lblTransaction.TabIndex = 7;
            lblTransaction.Text = "Transaction Amount (FCFA):";

            // txtTransaction
            txtTransaction.Location = new Point(240, 487);
            txtTransaction.Name = "txtTransaction";
            txtTransaction.Size = new Size(200, 27);
            txtTransaction.TabIndex = 8;

            // btnDeposit
            btnDeposit.Location = new Point(470, 480);
            btnDeposit.Name = "btnDeposit";
            btnDeposit.Size = new Size(150, 45);
            btnDeposit.TabIndex = 9;
            btnDeposit.Text = "Deposit";
            btnDeposit.UseVisualStyleBackColor = true;
            btnDeposit.Click += btnDeposit_Click;

            // btnWithdraw
            btnWithdraw.Location = new Point(650, 480);
            btnWithdraw.Name = "btnWithdraw";
            btnWithdraw.Size = new Size(150, 45);
            btnWithdraw.TabIndex = 10;
            btnWithdraw.Text = "Withdraw";
            btnWithdraw.UseVisualStyleBackColor = true;
            btnWithdraw.Click += btnWithdraw_Click;

            // Form1
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 560);
            Controls.Add(btnWithdraw);
            Controls.Add(btnDeposit);
            Controls.Add(txtTransaction);
            Controls.Add(lblTransaction);
            Controls.Add(dgvAccounts);
            Controls.Add(btnCreate);
            Controls.Add(txtAmount);
            Controls.Add(lblInitialAmount);
            Controls.Add(txtOwner);
            Controls.Add(lbOwner);
            Controls.Add(lbTitle);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NGASKA FIRST BANK";

            ((System.ComponentModel.ISupportInitialize)dgvAccounts).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbTitle;
        private Label lbOwner;
        private TextBox txtOwner;
        private Label lblInitialAmount;
        private TextBox txtAmount;
        private Button btnCreate;
        private DataGridView dgvAccounts;
        private Label lblTransaction;
        private TextBox txtTransaction;
        private Button btnDeposit;
        private Button btnWithdraw;
    }
}