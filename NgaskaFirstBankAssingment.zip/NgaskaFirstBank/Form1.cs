using System;

using System.Collections.Generic;

using System.Windows.Forms;

namespace BankManagementApp

{

    public partial class Form1 : Form

    {

        private readonly List<BankAccount> accounts =

            new List<BankAccount>();

        public Form1()

        {

            InitializeComponent();

            dgvAccounts.AutoGenerateColumns = true;

            dgvAccounts.ReadOnly = true;

            dgvAccounts.AllowUserToAddRows = false;

            dgvAccounts.SelectionMode =

                DataGridViewSelectionMode.FullRowSelect;

            dgvAccounts.MultiSelect = false;

            dgvAccounts.AutoSizeColumnsMode =

                DataGridViewAutoSizeColumnsMode.Fill;

            RefreshAccounts();

        }

        private void btnCreate_Click(object sender, EventArgs e)

        {

            string owner = txtOwner.Text.Trim();

            if (string.IsNullOrWhiteSpace(owner))

            {

                MessageBox.Show("Please enter the owner's name.");

                txtOwner.Focus();

                return;

            }

            decimal initialAmount = 0;

            if (!string.IsNullOrWhiteSpace(txtAmount.Text))

            {

                if (!decimal.TryParse(

                    txtAmount.Text.Trim(), out initialAmount) ||

                    initialAmount < 0)

                {

                    MessageBox.Show(

                        "Enter a valid initial amount of zero or more.");

                    txtAmount.Focus();

                    return;

                }

            }

            try

            {

                BankAccount account =

                    new BankAccount(owner, initialAmount);

                accounts.Add(account);

                RefreshAccounts();

                SelectAccount(account);

                txtOwner.Clear();

                txtAmount.Clear();

                MessageBox.Show(

                    "Account created successfully!\n" +

                    "Account Number: " + account.AccountNumber +

                    "\nInitial Balance: " +

                    account.Balance.ToString("N0") + " FCFA");

            }

            catch (Exception ex)

            {

                MessageBox.Show(

                    "Could not create account:\n" + ex.Message);

            }

        }

        // Select the account row without using CurrentCell.

        private void SelectAccount(BankAccount account)

        {

            dgvAccounts.ClearSelection();

            foreach (DataGridViewRow row in dgvAccounts.Rows)

            {

                if (row.IsNewRow || row.Index < 0)

                    continue;

                BankAccount rowAccount =

                    row.DataBoundItem as BankAccount;

                if (rowAccount != null &&

                    rowAccount.AccountNumber == account.AccountNumber)

                {

                    row.Selected = true;

                    return;

                }

            }

        }

        // Get the account from the selected row.

        private BankAccount GetSelectedAccount()

        {

            if (dgvAccounts.SelectedRows.Count > 0)

            {

                return dgvAccounts.SelectedRows[0].DataBoundItem

                    as BankAccount;

            }

            MessageBox.Show(

                "Please click an account row in the table first.");

            return null;

        }

        private void btnDeposit_Click(object sender, EventArgs e)

        {

            BankAccount account = GetSelectedAccount();

            if (account == null)

                return;

            decimal amount;

            if (!decimal.TryParse(

                txtTransaction.Text.Trim(), out amount) ||

                amount <= 0)

            {

                MessageBox.Show(

                    "Enter a valid deposit amount greater than zero.");

                txtTransaction.Focus();

                return;

            }

            try

            {

                account.Deposit(amount);

                RefreshAccounts();

                SelectAccount(account);

                txtTransaction.Clear();

                MessageBox.Show(

                    "Deposit successful!\nNew Balance: " +

                    account.Balance.ToString("N0") + " FCFA");

            }

            catch (Exception ex)

            {

                MessageBox.Show("Deposit failed:\n" + ex.Message);

            }

        }

        private void btnWithdraw_Click(object sender, EventArgs e)

        {

            BankAccount account = GetSelectedAccount();

            if (account == null)

                return;

            decimal amount;

            if (!decimal.TryParse(

                txtTransaction.Text.Trim(), out amount) ||

                amount <= 0)

            {

                MessageBox.Show(

                    "Enter a valid withdrawal amount greater than zero.");

                txtTransaction.Focus();

                return;

            }

            try

            {

                account.Withdraw(amount);

                RefreshAccounts();

                SelectAccount(account);

                txtTransaction.Clear();

                MessageBox.Show(

                    "Withdrawal successful!\nNew Balance: " +

                    account.Balance.ToString("N0") + " FCFA");

            }

            catch (Exception ex)

            {

                MessageBox.Show("Withdrawal failed:\n" + ex.Message);

            }

        }

        private void RefreshAccounts()

        {

            dgvAccounts.DataSource = null;

            dgvAccounts.DataSource = accounts;

            if (dgvAccounts.Columns.Contains("AccountNumber"))

                dgvAccounts.Columns["AccountNumber"].HeaderText =

                    "Account Number";

            if (dgvAccounts.Columns.Contains("Owner"))

                dgvAccounts.Columns["Owner"].HeaderText = "Owner";

            if (dgvAccounts.Columns.Contains("Balance"))

            {

                dgvAccounts.Columns["Balance"].HeaderText =

                    "Balance (FCFA)";

                dgvAccounts.Columns["Balance"]

                    .DefaultCellStyle.Format = "N0";

            }

        }

    }

}