using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace BankManagementApp
{
    public partial class Form1 : Form
    {
        private readonly List<BankAccount> accounts = new List<BankAccount>();
        private readonly Random random = new Random();

        // Controls
        private Label lblOwner;
        private TextBox txtOwner;
        private Label lblAmount;
        private NumericUpDown numAmount;
        private Button btnCreateAccount;
        private DataGridView dgvAccounts;
        private Button btnDeposit;
        private Button btnWithdraw;

        public Form1()
        {
            InitializeComponent();
            SetupTable();
            LoadInitialData();

            // Connect the buttons to their event handlers.
            btnCreateAccount.Click += btnCreateAccount_Click;
            btnDeposit.Click += btnDeposit_Click;
            btnWithdraw.Click += btnWithdraw_Click;
        }

        private void SetupTable()
        {
            dgvAccounts.Columns.Clear();
            dgvAccounts.Rows.Clear();

            dgvAccounts.Columns.Add("Owner", "Owner");
            dgvAccounts.Columns.Add("AccountNumber", "Account Number");
            dgvAccounts.Columns.Add("Balance", "Amount (FCFA)");

            dgvAccounts.ReadOnly = true;
            dgvAccounts.AllowUserToAddRows = false;
            dgvAccounts.MultiSelect = false;
            dgvAccounts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void LoadInitialData()
        {
            // Initial data matching the lab board notes
            accounts.Add(new BankAccount("ELOMBA", GenerateAccountNumber(), 250000));
            accounts.Add(new BankAccount("BARKA", GenerateAccountNumber(), 355740));
            accounts.Add(new BankAccount("ARINATA", GenerateAccountNumber(), 125000));
            DisplayAccounts();
        }

        private string GenerateAccountNumber()
        {
            string number;
            do
            {
                number = "DE-" + random.Next(100000, 1000000).ToString();
            }
            while (accounts.Exists(a => a.AccountNumber == number));

            return number;
        }

        private void DisplayAccounts()
        {
            dgvAccounts.Rows.Clear();

            foreach (BankAccount account in accounts)
            {
                int rowIndex = dgvAccounts.Rows.Add(
                    account.Owner,
                    account.AccountNumber,
                    account.Balance.ToString("N0")
                );

                dgvAccounts.Rows[rowIndex].Tag = account;
            }
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            string owner = txtOwner.Text.Trim();
            decimal amount = numAmount.Value;

            if (string.IsNullOrWhiteSpace(owner))
            {
                MessageBox.Show("Please enter the account owner's name.");
                txtOwner.Focus();
                return;
            }

            if (amount < 0)
            {
                MessageBox.Show("The initial balance cannot be negative.");
                return;
            }

            string accountNumber = GenerateAccountNumber();
            BankAccount account = new BankAccount(owner, accountNumber, amount);

            accounts.Add(account);
            DisplayAccounts();

            MessageBox.Show(
                "Account created successfully!\n" +
                "Account Number: " + accountNumber
            );

            txtOwner.Clear();
            numAmount.Value = 0;
        }

        private BankAccount GetSelectedAccount()
        {
            if (dgvAccounts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an account from the table.");
                return null;
            }

            return dgvAccounts.SelectedRows[0].Tag as BankAccount;
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();
            if (account == null) return;

            decimal amount = numAmount.Value;
            if (amount <= 0)
            {
                MessageBox.Show("Enter a deposit amount greater than zero.");
                return;
            }

            account.Deposit(amount);
            DisplayAccounts();

            MessageBox.Show(
                "Deposit successful!\nNew balance: " +
                account.Balance.ToString("N0") + " FCFA"
            );
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();
            if (account == null) return;

            decimal amount = numAmount.Value;
            if (amount <= 0)
            {
                MessageBox.Show("Enter a withdrawal amount greater than zero.");
                return;
            }

            if (amount > account.Balance)
            {
                MessageBox.Show("Insufficient balance!");
                return;
            }

            account.Withdraw(amount);
            DisplayAccounts();

            MessageBox.Show(
                "Withdrawal successful!\nNew balance: " +
                account.Balance.ToString("N0") + " FCFA"
            );
        }

        private void InitializeComponent()
        {
            lblOwner = new Label();
            txtOwner = new TextBox();
            btnCreateAccount = new Button();
            lblAmount = new Label();
            numAmount = new NumericUpDown();
            dgvAccounts = new DataGridView();
            btnDeposit = new Button();
            btnWithdraw = new Button();
            OWNER = new DataGridViewTextBoxColumn();
            Account = new DataGridViewTextBoxColumn();
            Amount = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)numAmount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).BeginInit();
            SuspendLayout();
            // 
            // lblOwner
            // 
            lblOwner.AutoSize = true;
            lblOwner.Location = new Point(30, 45);
            lblOwner.Name = "lblOwner";
            lblOwner.Size = new Size(55, 20);
            lblOwner.TabIndex = 7;
            lblOwner.Text = "Owner:";
            // 
            // txtOwner
            // 
            txtOwner.Location = new Point(100, 42);
            txtOwner.Name = "txtOwner";
            txtOwner.Size = new Size(190, 27);
            txtOwner.TabIndex = 6;
            // 
            // btnCreateAccount
            // 
            btnCreateAccount.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            btnCreateAccount.Location = new Point(100, 85);
            btnCreateAccount.Name = "btnCreateAccount";
            btnCreateAccount.Size = new Size(190, 35);
            btnCreateAccount.TabIndex = 5;
            btnCreateAccount.Text = "CREATE ACCOUNT";
            btnCreateAccount.UseVisualStyleBackColor = true;
            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.Location = new Point(30, 155);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(65, 20);
            lblAmount.TabIndex = 4;
            lblAmount.Text = "Amount:";
            // 
            // numAmount
            // 
            numAmount.Location = new Point(100, 153);
            numAmount.Maximum = new decimal(new int[] { 10000000, 0, 0, 0 });
            numAmount.Name = "numAmount";
            numAmount.Size = new Size(190, 27);
            numAmount.TabIndex = 3;
            // 
            // dgvAccounts
            // 
            dgvAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAccounts.Columns.AddRange(new DataGridViewColumn[] { OWNER, Account, Amount });
            dgvAccounts.Location = new Point(320, 21);
            dgvAccounts.Name = "dgvAccounts";
            dgvAccounts.RowHeadersWidth = 51;
            dgvAccounts.Size = new Size(500, 200);
            dgvAccounts.TabIndex = 2;
            // 
            // btnDeposit
            // 
            btnDeposit.Location = new Point(320, 260);
            btnDeposit.Name = "btnDeposit";
            btnDeposit.Size = new Size(230, 40);
            btnDeposit.TabIndex = 1;
            btnDeposit.Text = "Deposit";
            btnDeposit.UseVisualStyleBackColor = true;
            // 
            // btnWithdraw
            // 
            btnWithdraw.Location = new Point(590, 260);
            btnWithdraw.Name = "btnWithdraw";
            btnWithdraw.Size = new Size(230, 40);
            btnWithdraw.TabIndex = 0;
            btnWithdraw.Text = "WithDraw";
            btnWithdraw.UseVisualStyleBackColor = true;
            // 
            // OWNER
            // 
            OWNER.HeaderText = "Owner";
            OWNER.MinimumWidth = 6;
            OWNER.Name = "OWNER";
            OWNER.Width = 125;
            // 
            // Account
            // 
            Account.HeaderText = "Account";
            Account.MinimumWidth = 6;
            Account.Name = "Account";
            Account.Width = 125;
            // 
            // Amount
            // 
            Amount.HeaderText = "Amount (XAF)";
            Amount.MinimumWidth = 6;
            Amount.Name = "Amount";
            Amount.Width = 125;
            // 
            // Form1
            // 
            ClientSize = new Size(860, 340);
            Controls.Add(btnWithdraw);
            Controls.Add(btnDeposit);
            Controls.Add(dgvAccounts);
            Controls.Add(numAmount);
            Controls.Add(lblAmount);
            Controls.Add(btnCreateAccount);
            Controls.Add(txtOwner);
            Controls.Add(lblOwner);
            Name = "Form1";
            Text = "BARKA FIRST BANK SUBSCRIBERS";
            ((System.ComponentModel.ISupportInitialize)numAmount).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private DataGridViewTextBoxColumn OWNER;
        private DataGridViewTextBoxColumn Account;
        private DataGridViewTextBoxColumn Amount;
    }
}