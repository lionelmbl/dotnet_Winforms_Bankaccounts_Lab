﻿namespace BankManagementApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblOwner = new Label();
            txtOwner = new TextBox();
            lblInitialAmount = new Label();
            txtAmount = new TextBox();
            btnCreate = new Button();
            dgvAccounts = new DataGridView();
            Owner = new DataGridViewTextBoxColumn();
            AccountNumber = new DataGridViewTextBoxColumn();
            Balance = new DataGridViewTextBoxColumn();
            lblTransaction = new Label();
            txtTransaction = new TextBox();
            btnDeposit = new Button();
            btnWithdraw = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).BeginInit();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.BackColor = Color.Green;
            lblTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTitle.ForeColor = SystemColors.Control;
            lblTitle.Location = new Point(30, 20);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(435, 54);
            lblTitle.TabIndex = 9;
            lblTitle.Text = "ALAPANI FIRST BANK";
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblOwner
            // 
            lblOwner.AutoSize = true;
            lblOwner.Location = new Point(30, 85);
            lblOwner.Name = "lblOwner";
            lblOwner.Size = new Size(132, 25);
            lblOwner.TabIndex = 10;
            lblOwner.Text = "Owner Name :";
            // 
            // txtOwner
            // 
            txtOwner.Location = new Point(151, 82);
            txtOwner.Name = "txtOwner";
            txtOwner.Size = new Size(314, 33);
            txtOwner.TabIndex = 11;
            // 
            // lblInitialAmount
            // 
            lblInitialAmount.AutoSize = true;
            lblInitialAmount.Location = new Point(33, 126);
            lblInitialAmount.Name = "lblInitialAmount";
            lblInitialAmount.Size = new Size(198, 25);
            lblInitialAmount.TabIndex = 12;
            lblInitialAmount.Text = "Initial Amount (FCFA) :";
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(237, 122);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(228, 33);
            txtAmount.TabIndex = 13;
            // 
            // btnCreate
            // 
            btnCreate.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnCreate.Location = new Point(100, 200);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(180, 45);
            btnCreate.TabIndex = 14;
            btnCreate.Text = "Create Account";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;
            // 
            // dgvAccounts
            // 
            dgvAccounts.AllowUserToAddRows = false;
            dgvAccounts.AllowUserToResizeColumns = false;
            dgvAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAccounts.Columns.AddRange(new DataGridViewColumn[] { Owner, AccountNumber, Balance });
            // Sample rows displayed in the Visual Studio Designer preview.
            dgvAccounts.Rows.Add("AMINATA", "807080", 1125000);
            dgvAccounts.Rows.Add("ELOMBA", "777375", 750000);
            dgvAccounts.Rows.Add("BARKA", "938059", 250000);
            dgvAccounts.Rows.Add("OCEANNE", "380845", 90000);

            dgvAccounts.GridColor = SystemColors.Info;
            dgvAccounts.Location = new Point(471, 20);
            dgvAccounts.MultiSelect = false;
            dgvAccounts.Name = "dgvAccounts";
            dgvAccounts.ReadOnly = true;
            dgvAccounts.RowHeadersWidth = 62;
            dgvAccounts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAccounts.Size = new Size(634, 425);
            dgvAccounts.TabIndex = 15;
            dgvAccounts.CellContentClick += dgvAccounts_CellContentClick;
            // 
            // Owner
            // 
            Owner.HeaderText = "Owner";
            Owner.MinimumWidth = 8;
            Owner.Name = "Owner";
            Owner.ReadOnly = true;
            // 
            // AccountNumber
            // 
            AccountNumber.HeaderText = "Account Number";
            AccountNumber.MinimumWidth = 8;
            AccountNumber.Name = "AccountNumber";
            AccountNumber.ReadOnly = true;
            // 
            // Balance
            // 
            Balance.HeaderText = "Balance (FCFA)";
            Balance.MinimumWidth = 8;
            Balance.Name = "Balance";
            Balance.ReadOnly = true;
            // 
            // lblTransaction
            // 
            lblTransaction.AutoSize = true;
            lblTransaction.Location = new Point(38, 416);
            lblTransaction.Name = "lblTransaction";
            lblTransaction.Size = new Size(242, 25);
            lblTransaction.TabIndex = 16;
            lblTransaction.Text = "Transaction Amount (FCFA):";
            // 
            // txtTransaction
            // 
            txtTransaction.Location = new Point(286, 412);
            txtTransaction.Name = "txtTransaction";
            txtTransaction.Size = new Size(150, 33);
            txtTransaction.TabIndex = 17;
            // 
            // btnDeposit
            // 
            btnDeposit.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnDeposit.Location = new Point(691, 478);
            btnDeposit.Name = "btnDeposit";
            btnDeposit.Size = new Size(112, 34);
            btnDeposit.TabIndex = 18;
            btnDeposit.Text = "Deposit";
            btnDeposit.UseVisualStyleBackColor = true;
            btnDeposit.Click += btnDeposit_Click;
            // 
            // btnWithdraw
            // 
            btnWithdraw.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnWithdraw.Location = new Point(832, 477);
            btnWithdraw.Name = "btnWithdraw";
            btnWithdraw.Size = new Size(112, 34);
            btnWithdraw.TabIndex = 19;
            btnWithdraw.Text = "withdraw";
            btnWithdraw.UseVisualStyleBackColor = true;
            btnWithdraw.Click += btnWithdraw_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(11F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(128, 64, 64);
            ClientSize = new Size(1117, 594);
            Controls.Add(btnWithdraw);
            Controls.Add(btnDeposit);
            Controls.Add(txtTransaction);
            Controls.Add(lblTransaction);
            Controls.Add(dgvAccounts);
            Controls.Add(btnCreate);
            Controls.Add(txtAmount);
            Controls.Add(lblInitialAmount);
            Controls.Add(txtOwner);
            Controls.Add(lblOwner);
            Controls.Add(lblTitle);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ALAPANI FIRST BANK";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblOwner;
        private TextBox txtOwner;
        private Label lblInitialAmount;
        private TextBox txtAmount;
        private Button btnCreate;
        private DataGridView dgvAccounts;
        private Label lblTransaction;
        private TextBox txtTransaction;
        private Button btnDeposit;
        private Button btnWithdraw;
        private DataGridViewTextBoxColumn Owner;
        private DataGridViewTextBoxColumn AccountNumber;
        private DataGridViewTextBoxColumn Balance;
    }
}
