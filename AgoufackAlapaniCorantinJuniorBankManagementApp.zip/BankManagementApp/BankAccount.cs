﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankManagementApp
{
    public class BankAccount
    {
        public string Owner { get; set; }
        public string AccountNumber { get;private  set; }
        public decimal Balance { get; private set; }

        public BankAccount(string owner, decimal initialBalance)
        {
            Owner = owner;
            AccountNumber = Random.Shared.Next(100000, 1000000).ToString ();
            Balance = initialBalance;
        }
        public void Deposit(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Deposit amount must be positive.");
            }
            Balance += amount;
        }
        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
            {
                throw new ArgumentException("Withdrawal amount must be positive.");
            }
            if (amount > Balance)
            {
                throw new InvalidOperationException("Insufficient funds for this withdrawal.");
            }
            Balance -= amount;
        }
    }
}
