using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace BankManagementApp
{
    public partial class Form1 : Form
    {
        private readonly List<BankAccount> accounts =
            new List<BankAccount>();

        public Form1()
        {
            InitializeComponent();

            // Configure the accounts grid.
            dgvAccounts.DataSource = null;
            dgvAccounts.AutoGenerateColumns = false;
            dgvAccounts.ReadOnly = true;
            dgvAccounts.Enabled = true;
            dgvAccounts.AllowUserToAddRows = false;
            dgvAccounts.AllowUserToDeleteRows = false;
            dgvAccounts.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            dgvAccounts.MultiSelect = false;
            dgvAccounts.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            // Create the grid columns manually.
            dgvAccounts.Columns.Clear();

            dgvAccounts.Columns.Add("Owner", "Owner");

            dgvAccounts.Columns.Add(
                "AccountNumber", "Account Number");

            dgvAccounts.Columns.Add(
                "Balance", "Balance (FCFA)");

            dgvAccounts.Columns["Balance"]
                .DefaultCellStyle.Format = "N0";

            // Show sample rows when the Designer is displaying
            // the form. This is only a preview.
            if (LicenseManager.UsageMode ==
                LicenseUsageMode.Designtime)
            {
                ShowDesignTimeAccounts();
                return;
            }

            // SEEDED ACCOUNTS
            accounts.Add(
                new BankAccount("AMINATA", 1125000m));

            accounts.Add(
                new BankAccount("ELOMBA", 750000m));

            accounts.Add(
                new BankAccount("BARKA", 250000m));

            accounts.Add(
                new BankAccount("OCEANNE", 90000m));

            // Display the seeded accounts when the app runs.
            RefreshAccounts();
        }

        // DESIGN-TIME SAMPLE ROWS
        private void ShowDesignTimeAccounts()
        {
            dgvAccounts.Rows.Clear();

            dgvAccounts.Rows.Add(
                "AMINATA", "807080", 1125000);

            dgvAccounts.Rows.Add(
                "ELOMBA", "777375", 750000);

            dgvAccounts.Rows.Add(
                "BARKA", "938059", 250000);

            dgvAccounts.Rows.Add(
                "OCEANNE", "380845", 90000);
        }

        // CREATE A NEW ACCOUNT
        private void btnCreate_Click(object sender, EventArgs e)
        {
            string owner = txtOwner.Text.Trim();

            // Validate the owner's name.
            if (string.IsNullOrWhiteSpace(owner))
            {
                MessageBox.Show(
                    "Please enter the account owner's name.",
                    "Missing Name",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtOwner.Focus();
                return;
            }

            // The name must contain at least one letter.
            // Numbers alone cannot be used as an owner's name.
            bool containsLetter = false;

            foreach (char character in owner)
            {
                if (char.IsLetter(character))
                {
                    containsLetter = true;
                    break;
                }
            }

            if (!containsLetter)
            {
                MessageBox.Show(
                    "The owner's name must contain letters. " +
                    "An account number cannot be used as a name.",
                    "Invalid Owner Name",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtOwner.Focus();
                txtOwner.SelectAll();
                return;
            }

            // Validate the initial amount.
            if (!decimal.TryParse(
                txtAmount.Text, out decimal amount)
                || amount < 0)
            {
                MessageBox.Show(
                    "Enter a valid initial amount " +
                    "(zero or greater).",
                    "Invalid Amount",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtAmount.Focus();
                txtAmount.SelectAll();
                return;
            }

            // Create the account after validation succeeds.
            BankAccount account =
                new BankAccount(owner, amount);

            accounts.Add(account);

            RefreshAccounts();

            txtOwner.Clear();
            txtAmount.Clear();

            MessageBox.Show(
                "Account created successfully!\n" +
                "Owner: " + account.Owner +
                "\nAccount number: " + account.AccountNumber,
                "Success",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        // GET THE SELECTED ACCOUNT
        private BankAccount GetSelectedAccount()
        {
            if (dgvAccounts.SelectedRows.Count == 0)
            {
                return null;
            }

            DataGridViewRow row =
                dgvAccounts.SelectedRows[0];

            // Each row is associated with its account.
            return row.Tag as BankAccount;
        }

        // DEPOSIT MONEY
        private void btnDeposit_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();

            if (account == null)
            {
                MessageBox.Show(
                    "Please select an account row first.",
                    "No Account Selected",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            if (!decimal.TryParse(
                txtTransaction.Text, out decimal amount))
            {
                MessageBox.Show(
                    "Enter a valid transaction amount.",
                    "Invalid Amount",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtTransaction.Focus();
                txtTransaction.SelectAll();
                return;
            }

            try
            {
                account.Deposit(amount);

                RefreshAccounts();

                txtTransaction.Clear();

                MessageBox.Show(
                    "Deposit successful!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Deposit Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // WITHDRAW MONEY
        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();

            if (account == null)
            {
                MessageBox.Show(
                    "Please select an account row first.",
                    "No Account Selected",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            if (!decimal.TryParse(
                txtTransaction.Text, out decimal amount))
            {
                MessageBox.Show(
                    "Enter a valid transaction amount.",
                    "Invalid Amount",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtTransaction.Focus();
                txtTransaction.SelectAll();
                return;
            }

            try
            {
                account.Withdraw(amount);

                RefreshAccounts();

                txtTransaction.Clear();

                MessageBox.Show(
                    "Withdrawal successful!",
                    "Success",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Withdrawal Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Withdrawal Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        // REFRESH THE GRID WITHOUT DATA BINDING
        private void RefreshAccounts()
        {
            // Clear displayed rows, not the accounts list.
            dgvAccounts.Rows.Clear();

            foreach (BankAccount account in accounts)
            {
                int rowIndex = dgvAccounts.Rows.Add(
                    account.Owner,
                    account.AccountNumber,
                    account.Balance);

                // Associate the row with its account.
                dgvAccounts.Rows[rowIndex].Tag = account;
            }

            // Clear the selection after refreshing.
            dgvAccounts.ClearSelection();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // No additional load actions are required.
        }

        private void dgvAccounts_CellContentClick(
            object sender, DataGridViewCellEventArgs e)
        {
            // No action required.
        }
    }
}
