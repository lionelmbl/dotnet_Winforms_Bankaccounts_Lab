﻿namespace BankForm_App
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreate = new Button();
            txtName = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            dgvOwners = new DataGridView();
            btnDeposit = new Button();
            btnWithdraw = new Button();
            label3 = new Label();
            txtAmount = new TextBox();
            txtBalance = new TextBox();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvOwners).BeginInit();
            SuspendLayout();
            // 
            // btnCreate
            // 
            btnCreate.AccessibleName = "btnCreate";
            btnCreate.Location = new Point(236, 347);
            btnCreate.Name = "btnCreate";
            btnCreate.Size = new Size(237, 43);
            btnCreate.TabIndex = 0;
            btnCreate.Text = "Create Account";
            btnCreate.UseVisualStyleBackColor = true;
            btnCreate.Click += btnCreate_Click;
            // 
            // txtName
            // 
            txtName.AccessibleName = "txtName";
            txtName.Location = new Point(196, 132);
            txtName.Name = "txtName";
            txtName.Size = new Size(323, 39);
            txtName.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(88, 139);
            label1.Name = "label1";
            label1.Size = new Size(84, 32);
            label1.TabIndex = 2;
            label1.Text = "Owner";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(88, 480);
            label2.Name = "label2";
            label2.Size = new Size(100, 32);
            label2.TabIndex = 3;
            label2.Text = "Amount";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(196, 238);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(0, 39);
            textBox2.TabIndex = 4;
            // 
            // dgvOwners
            // 
            dgvOwners.AccessibleName = "dgvOwners";
            dgvOwners.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOwners.Location = new Point(746, 139);
            dgvOwners.Name = "dgvOwners";
            dgvOwners.RowHeadersWidth = 82;
            dgvOwners.Size = new Size(763, 441);
            dgvOwners.TabIndex = 5;
            // 
            // btnDeposit
            // 
            btnDeposit.AccessibleName = "btnDeposit";
            btnDeposit.Location = new Point(25, 540);
            btnDeposit.Name = "btnDeposit";
            btnDeposit.Size = new Size(287, 55);
            btnDeposit.TabIndex = 6;
            btnDeposit.Text = "Deposit";
            btnDeposit.UseVisualStyleBackColor = true;
            btnDeposit.Click += btnDeposit_Click;
            // 
            // btnWithdraw
            // 
            btnWithdraw.AccessibleName = "btnWithdraw";
            btnWithdraw.Location = new Point(364, 540);
            btnWithdraw.Name = "btnWithdraw";
            btnWithdraw.Size = new Size(287, 55);
            btnWithdraw.TabIndex = 7;
            btnWithdraw.Text = "Withdraw";
            btnWithdraw.UseVisualStyleBackColor = true;
            btnWithdraw.Click += btnWithdraw_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(13, 263);
            label3.Name = "label3";
            label3.Size = new Size(165, 32);
            label3.TabIndex = 10;
            label3.Text = "Initial Amount";
            // 
            // txtAmount
            // 
            txtAmount.AccessibleName = "txtName";
            txtAmount.Location = new Point(196, 477);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(323, 39);
            txtAmount.TabIndex = 13;
            // 
            // txtBalance
            // 
            txtBalance.AccessibleName = "txtName";
            txtBalance.Location = new Point(196, 263);
            txtBalance.Name = "txtBalance";
            txtBalance.Size = new Size(323, 39);
            txtBalance.TabIndex = 14;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 26F);
            label4.Location = new Point(554, 9);
            label4.Name = "label4";
            label4.Size = new Size(448, 93);
            label4.TabIndex = 15;
            label4.Text = "Hermes Bank";
            label4.TextAlign = ContentAlignment.TopRight;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1560, 780);
            Controls.Add(label4);
            Controls.Add(txtBalance);
            Controls.Add(txtAmount);
            Controls.Add(label3);
            Controls.Add(btnWithdraw);
            Controls.Add(btnDeposit);
            Controls.Add(dgvOwners);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtName);
            Controls.Add(btnCreate);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvOwners).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCreate;
        private TextBox txtName;
        private Label label1;
        private Label label2;
        private TextBox textBox2;
        private DataGridView dgvOwners;
        private Button btnDeposit;
        private Button btnWithdraw;
        private Label label3;
        private TextBox txtAmount;
        private TextBox txtBalance;
        private Label label4;
    }
}
