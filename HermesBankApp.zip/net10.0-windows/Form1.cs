using System.ComponentModel;


namespace BankForm_App
{
    public partial class Form1 : Form
    {
        private BindingList<Owner> owners = new BindingList<Owner>();
        public Form1()
        {
            InitializeComponent();

            dgvOwners.AutoGenerateColumns = true;
            dgvOwners.DataSource = owners;

            dgvOwners.ReadOnly = true;
            dgvOwners.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvOwners.MultiSelect = false;
            dgvOwners.AllowUserToAddRows = false;

            dgvOwners.Columns["Amount"]
                .DefaultCellStyle.Format = "N2";
        }

        private int GenerateAccountNumber()
        {
            int accountNumber;

            do
            {
                accountNumber = Random.Shared.Next(100000, 1000000);
            }
            while (owners.Any(owner =>
                owner.AccountNumber == accountNumber));

            return accountNumber;
        }

        private Owner? GetSelectedOwner()
        {
            if (dgvOwners.CurrentRow == null)
                return null;

            return dgvOwners.CurrentRow.DataBoundItem as Owner;
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            Owner? owner = GetSelectedOwner();

            if (owner == null)
            {
                MessageBox.Show("Please select an owner.");
                return;
            }

            if (!decimal.TryParse(txtAmount.Text, out decimal amount))
            {
                MessageBox.Show("Invalid amount.");
                return;
            }

            bool success = owner.Deposit(amount);

            if (success)
            {
                MessageBox.Show("Deposit successful!");
                txtAmount.Clear();
            }
            else
            {
                MessageBox.Show("Amount must be greater than zero.");
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter a name.");
                return;
            }

            if (!decimal.TryParse(txtBalance.Text, out decimal balance)
                || balance < 0)
            {
                MessageBox.Show("Invalid initial balance.");
                return;
            }

            // Automatically generate a unique account number
            int accountNumber = GenerateAccountNumber();

            // Create the new owner
            Owner newOwner = new Owner(name, accountNumber, balance);

            // Add owner to the list
            owners.Add(newOwner);

            MessageBox.Show(
                $"Account created successfully!\n" +
                $"Owner: {name}\n" +
                $"Account Number: {accountNumber}"
            );

            txtName.Clear();
            txtBalance.Clear();
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            Owner? owner = GetSelectedOwner();

            if (owner == null)
            {
                MessageBox.Show("Please select an owner.");
                return;
            }

            if (!decimal.TryParse(txtAmount.Text, out decimal amount)
                || amount <= 0)
            {
                MessageBox.Show("Invalid withdrawal amount.");
                return;
            }

            if (amount > owner.Amount)
            {
                MessageBox.Show("Insufficient balance.");
                return;
            }

            bool success = owner.Withdraw(amount);

            if (success)
            {
                MessageBox.Show("Withdrawal successful!");
                txtAmount.Clear();
            }
        }
    }
}


public class Owner : INotifyPropertyChanged
{
    public string Name { get; private set; }
    public int AccountNumber { get; private set; }

    private decimal amount;

    public decimal Amount
    {
        get { return amount; }
        private set
        {
            amount = value;
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(nameof(Amount))
            );
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public Owner(string name, int accountNumber, decimal amount)
    {
        Name = name;
        AccountNumber = accountNumber;
        Amount = amount;
    }

    public bool Deposit(decimal depositAmount)
    {
        if (depositAmount <= 0)
            return false;

        Amount += depositAmount;
        return true;
    }

    public bool Withdraw(decimal withdrawAmount)
    {
        if (withdrawAmount <= 0 || withdrawAmount > Amount)
            return false;

        Amount -= withdrawAmount;
        return true;
    }
}