﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using WinFormsApp_ex1.Exceptions;

namespace WinFormsApp_ex1.Models
{
    public class BankAccount
    {
        public string Username { get; set; }
        public string AccountNumber { get; set;}
        public decimal Balance { get; set;}

        public BankAccount(string username,  decimal balance)
        {
            Username = username;
            Balance = balance;

            int num = Random.Shared.Next(10000, 99999);
            string mid = "ACC" + num + "y2026";
            AccountNumber = mid;

        }

        public void Deposit(decimal amount)
        {
            try
            {
                if (amount > 0)
                {
                    this.Balance += amount;
                    return;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("Input must be greater than zero");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Transaction Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
        public void Withdraw(decimal amount)
        {
            try
            {
                if (amount < this.Balance && amount > 0)
                {
                    this.Balance -= amount;
                    return;
                }
                else if (amount > this.Balance)
                {
                    throw new InsufficientFundsException("Cannot withdraw more than account balance");
                }
                else if (amount < 0)
                {
                    throw new InsufficientFundsException("Input must be greater than zero");
                    
                }
            }
            catch (InsufficientFundsException ex)
            {
                {
                    MessageBox.Show(ex.Message, "TransactionError", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
        }

  
    }
   
}