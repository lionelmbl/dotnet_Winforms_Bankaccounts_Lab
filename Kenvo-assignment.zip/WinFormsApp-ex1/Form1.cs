using System.ComponentModel;
using WinFormsApp_ex1.Models;

namespace WinFormsApp_ex1
{
    public partial class Form1 : Form
    {
        private BindingList<BankAccount> accountList;

        public Form1()
        {
            InitializeComponent();
            accountList = new BindingList<BankAccount> {
                new BankAccount("James Bond", 200),
                new BankAccount ("John Sam", 10000 ),
                new BankAccount("Jean Etoa", 4000)

            };
            dataGridView1.DataSource = accountList;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void deposit_click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow == null)
                {
                    MessageBox.Show("Please select an account from the table first.", "Selection required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                BankAccount selectedAccount = (BankAccount)dataGridView1.CurrentRow.DataBoundItem;
                decimal amountToDeposit = txtAmount.Value;
                selectedAccount.Deposit(amountToDeposit);
                dataGridView1.Refresh();
                txtAmount.Value = 0;
                MessageBox.Show($"Successfully deposited ${amountToDeposit} to {selectedAccount.Username}'s account.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid number.", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Deposit Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Withdraw_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow == null)
                {
                    MessageBox.Show("Please select an account from the table first.", "Selection required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                BankAccount selectedAccount = (BankAccount)dataGridView1.CurrentRow.DataBoundItem;
                decimal amountToWithdraw = txtAmount.Value;
                selectedAccount.Withdraw(amountToWithdraw);
                dataGridView1.Refresh();
                txtAmount.Value = 0;
                MessageBox.Show($"Successfully withdrawn ${amountToWithdraw} to {selectedAccount.Username}'s account.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid number.", "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Deposit Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void CreateAccount_Click(object sender, EventArgs e)
        {
            try
            {
                if (OwnerInput.Text != null)
                {
                    string nameInput = OwnerInput.Text;
                    BankAccount acc = new BankAccount(nameInput, 0);
                    accountList.Add(acc);
                    dataGridView1.Refresh();
                    MessageBox.Show($"Successfully created {nameInput}'s account","success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (ArgumentNullException ex)
            {
                {
                    MessageBox.Show("Empty field", "Enter a name to create an account", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
