﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp_ex1.Exceptions
{
    public class InsufficientFundsException: Exception
    {
        public InsufficientFundsException(string message) : base(message)
            { }
        
    }
}
