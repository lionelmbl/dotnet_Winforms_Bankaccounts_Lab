﻿namespace WinFormsApp_ex1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            panel1 = new Panel();
            label1 = new Label();
            panel3 = new Panel();
            label4 = new Label();
            txtAmount = new NumericUpDown();
            label3 = new Label();
            button3 = new Button();
            OwnerInput = new TextBox();
            label2 = new Label();
            button2 = new Button();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            Username = new DataGridViewTextBoxColumn();
            AccountNumber = new DataGridViewTextBoxColumn();
            Balance = new DataGridViewTextBoxColumn();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)txtAmount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.MidnightBlue;
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1306, 36);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Copperplate Gothic Light", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(35, 5);
            label1.Name = "label1";
            label1.Size = new Size(207, 26);
            label1.TabIndex = 1;
            label1.Text = "Joy First Bank ";
            // 
            // panel3
            // 
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(label4);
            panel3.Controls.Add(txtAmount);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(button3);
            panel3.Controls.Add(OwnerInput);
            panel3.Controls.Add(label2);
            panel3.Controls.Add(button2);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(dataGridView1);
            panel3.Location = new Point(64, 93);
            panel3.Name = "panel3";
            panel3.Size = new Size(1190, 613);
            panel3.TabIndex = 1;
            panel3.Paint += panel3_Paint;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(169, 346);
            label4.Name = "label4";
            label4.Size = new Size(157, 21);
            label4.TabIndex = 8;
            label4.Text = "(Maximum = 10,000)";
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(170, 312);
            txtAmount.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(316, 31);
            txtAmount.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Leelawadee", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(44, 309);
            label3.Name = "label3";
            label3.Size = new Size(120, 34);
            label3.TabIndex = 6;
            label3.Text = "Amount:";
            // 
            // button3
            // 
            button3.BackColor = Color.Tan;
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Leelawadee", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(219, 119);
            button3.Name = "button3";
            button3.Size = new Size(194, 38);
            button3.TabIndex = 5;
            button3.Text = "Create account";
            button3.UseVisualStyleBackColor = false;
            button3.Click += CreateAccount_Click;
            // 
            // OwnerInput
            // 
            OwnerInput.Location = new Point(153, 57);
            OwnerInput.Multiline = true;
            OwnerInput.Name = "OwnerInput";
            OwnerInput.Size = new Size(333, 41);
            OwnerInput.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Leelawadee", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(44, 60);
            label2.Name = "label2";
            label2.Size = new Size(103, 34);
            label2.TabIndex = 3;
            label2.Text = "Owner:";
            label2.Click += label2_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Sienna;
            button2.Cursor = Cursors.Hand;
            button2.Font = new Font("Leelawadee", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Image = Properties.Resources.payment_arrow_down_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24;
            button2.ImageAlign = ContentAlignment.MiddleRight;
            button2.Location = new Point(896, 460);
            button2.Name = "button2";
            button2.Padding = new Padding(0, 0, 25, 0);
            button2.Size = new Size(236, 45);
            button2.TabIndex = 2;
            button2.Text = "Withdraw";
            button2.UseVisualStyleBackColor = false;
            button2.Click += Withdraw_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGoldenrod;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Leelawadee", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Image = Properties.Resources.add_circle_24dp_1F1F1F_FILL0_wght400_GRAD0_opsz24;
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(643, 460);
            button1.Name = "button1";
            button1.Padding = new Padding(25, 0, 0, 0);
            button1.Size = new Size(238, 45);
            button1.TabIndex = 1;
            button1.Text = "Deposit";
            button1.UseVisualStyleBackColor = false;
            button1.Click += deposit_click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = SystemColors.Control;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Username, AccountNumber, Balance });
            dataGridView1.Location = new Point(567, 43);
            dataGridView1.MultiSelect = false;
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(611, 370);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Username
            // 
            Username.DataPropertyName = "Username";
            Username.HeaderText = "Owner";
            Username.MinimumWidth = 8;
            Username.Name = "Username";
            Username.ReadOnly = true;
            Username.Width = 150;
            // 
            // AccountNumber
            // 
            AccountNumber.DataPropertyName = "AccountNumber";
            AccountNumber.HeaderText = "Account Number";
            AccountNumber.MinimumWidth = 8;
            AccountNumber.Name = "AccountNumber";
            AccountNumber.ReadOnly = true;
            AccountNumber.Width = 250;
            // 
            // Balance
            // 
            Balance.DataPropertyName = "Balance";
            Balance.HeaderText = "Amount";
            Balance.MinimumWidth = 8;
            Balance.Name = "Balance";
            Balance.ReadOnly = true;
            Balance.ToolTipText = "User balance in account";
            Balance.Width = 150;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BlanchedAlmond;
            ClientSize = new Size(1307, 757);
            Controls.Add(panel3);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            Text = "JFB User Portal";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)txtAmount).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Panel panel3;
        private DataGridView dataGridView1;
        private Button button2;
        private Button button1;
        private Label label2;
        private Button button3;
        private TextBox OwnerInput;
        private NumericUpDown txtAmount;
        private Label label3;
        private Label label4;
        private DataGridViewTextBoxColumn Username;
        private DataGridViewTextBoxColumn AccountNumber;
        private DataGridViewTextBoxColumn Balance;
    }
}
