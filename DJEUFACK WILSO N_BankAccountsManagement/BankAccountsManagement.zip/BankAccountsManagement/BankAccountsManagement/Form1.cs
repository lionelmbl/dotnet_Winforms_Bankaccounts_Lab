﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace BankAccountsManagement
{
    public partial class Form1 : Form
    {
        // List of all the bank accounts, connected to the DataGridView
        private BindingList<BankAccount> accounts = new BindingList<BankAccount>();

        public Form1()
        {
            InitializeComponent();

            // Use only the 3 columns we designed (Owner, Account Number, Amount)
            dgvAccounts.AutoGenerateColumns = false;

            // Show amounts like 250 000 and align them to the right
            colAmount.DefaultCellStyle.Format = "N0";
            colAmount.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            LoadInitialAccounts();
            dgvAccounts.DataSource = accounts;

            // Connect the buttons to their code
            btnCreateAccount.Click += BtnCreateAccount_Click;
            btnDeposit.Click += BtnDeposit_Click;
            btnWithdraw.Click += BtnWithdraw_Click;
        }

        // The accounts created directly in the code (as asked by the teacher)
        private void LoadInitialAccounts()
        {
            accounts.Add(new BankAccount("ELOMBA", 250000));
            accounts.Add(new BankAccount("BARKA", 355740));
            accounts.Add(new BankAccount("AMINATA", 125000));
        }

        // ---------------- CREATE ACCOUNT ----------------
        private void BtnCreateAccount_Click(object sender, EventArgs e)
        {
            string owner = txtOwner.Text;

            if (string.IsNullOrWhiteSpace(owner))
            {
                MessageBox.Show("Please enter the owner's name.", "Missing name",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtOwner.Focus();
                return;
            }

            BankAccount newAccount = new BankAccount(owner);
            accounts.Add(newAccount);

            // Select the new account in the table
            int lastRow = dgvAccounts.Rows.Count - 1;
            dgvAccounts.ClearSelection();
            dgvAccounts.Rows[lastRow].Selected = true;
            dgvAccounts.CurrentCell = dgvAccounts.Rows[lastRow].Cells[0];

            MessageBox.Show("Account created for " + newAccount.Owner +
                "\nAccount number: " + newAccount.AccountNumber,
                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtOwner.Clear();
            txtOwner.Focus();
        }

        // ---------------- DEPOSIT ----------------
        private void BtnDeposit_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();
            if (account == null) return;

            decimal amount = nudAmount.Value;

            try
            {
                account.Deposit(amount);
                RefreshAccount(account);
                MessageBox.Show(amount.ToString("N0") + " deposited to " + account.Owner +
                    "\nNew balance: " + account.Balance.ToString("N0"),
                    "Deposit successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                nudAmount.Value = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Deposit failed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ---------------- WITHDRAW ----------------
        private void BtnWithdraw_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();
            if (account == null) return;

            decimal amount = nudAmount.Value;

            try
            {
                account.Withdraw(amount);
                RefreshAccount(account);
                MessageBox.Show(amount.ToString("N0") + " withdrawn from " + account.Owner +
                    "\nNew balance: " + account.Balance.ToString("N0"),
                    "Withdrawal successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
                nudAmount.Value = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Withdrawal failed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ---------------- HELPERS ----------------

        // Returns the account selected in the table, or null (with a warning) if none
        private BankAccount GetSelectedAccount()
        {
            if (dgvAccounts.CurrentRow == null)
            {
                MessageBox.Show("Please select an account in the table first.", "No account selected",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }

            return dgvAccounts.CurrentRow.DataBoundItem as BankAccount;
        }

        // Tells the table that this account's balance changed, so it redraws the row
        private void RefreshAccount(BankAccount account)
        {
            int index = accounts.IndexOf(account);
            if (index >= 0)
            {
                accounts.ResetItem(index);
            }
        }
    }
}