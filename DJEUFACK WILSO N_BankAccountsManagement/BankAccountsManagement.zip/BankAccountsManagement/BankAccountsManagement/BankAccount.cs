﻿using System;
using System.Collections.Generic;

namespace BankAccountsManagement
{
    /// <summary>
    /// Represents one bank account of MOONGO FIRST BANK.
    /// </summary>
    public class BankAccount
    {
        // One shared random generator for all accounts
        private static readonly Random random = new Random();

        // Keeps every number already given, so two accounts never get the same one
        private static readonly HashSet<string> usedNumbers = new HashSet<string>();

        // Properties (encapsulation: they can be read from outside, but only changed inside the class)
        public string Owner { get; private set; }
        public string AccountNumber { get; private set; }
        public decimal Balance { get; private set; }

        // Constructor
        public BankAccount(string owner, decimal initialBalance = 0)
        {
            if (string.IsNullOrWhiteSpace(owner))
                throw new ArgumentException("The owner name cannot be empty.");

            if (initialBalance < 0)
                throw new ArgumentException("The initial balance cannot be negative.");

            Owner = owner.Trim().ToUpper();
            AccountNumber = GenerateAccountNumber();
            Balance = initialBalance;
        }

        // Generates a random 11-digit account number, unique among all accounts
        private static string GenerateAccountNumber()
        {
            string number;
            do
            {
                number = "";
                for (int i = 0; i < 11; i++)
                {
                    number += random.Next(0, 10).ToString();
                }
            }
            while (usedNumbers.Contains(number));

            usedNumbers.Add(number);
            return number;
        }

        // Adds money to the account
        public void Deposit(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentException("The deposit amount must be greater than 0.");

            Balance += amount;
        }

        // Removes money from the account
        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentException("The withdrawal amount must be greater than 0.");

            if (amount > Balance)
                throw new InvalidOperationException("Insufficient balance. Current balance: " + Balance.ToString("N0"));

            Balance -= amount;
        }
    }
}