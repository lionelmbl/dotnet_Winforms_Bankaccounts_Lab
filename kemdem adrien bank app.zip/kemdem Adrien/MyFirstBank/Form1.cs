#nullable enable
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace BankManagementApp
{
    public partial class Form1 : Form
    {
        private readonly List<BankAccount> accounts = new List<BankAccount>();
        private readonly Random random = new Random();

        // Primary Controls
        private Label lblOwner = null!;
        private TextBox txtOwner = null!;
        private Label lblAmount = null!;
        private NumericUpDown numAmount = null!;
        private Button btnCreateAccount = null!;
        private DataGridView dgvAccounts = null!;
        private Button btnDeposit = null!;
        private Button btnWithdraw = null!;

        // Layout & Decorative Panels
        private Panel pnlHeader = null!;
        private Panel pnlGoldStripe = null!;
        private Panel pnlLeftCard = null!;
        private Panel pnlRightCard = null!;
        private Label lblHeaderTitle = null!;
        private Label lblHeaderSubtitle = null!;
        private Label lblLeftCardTitle = null!;
        private Label lblTransactionsTitle = null!;
        private Panel pnlDivider = null!;
        private Label lblTableTitle = null!;
        private Label lblInstruction = null!;

        public Form1()
        {
            InitializeComponent();
            SetupTable();
            LoadInitialData();

            // Connect the buttons to their event handlers
            btnCreateAccount.Click += btnCreateAccount_Click;
            btnDeposit.Click += btnDeposit_Click;
            btnWithdraw.Click += btnWithdraw_Click;
        }

        private void SetupTable()
        {
            dgvAccounts.Columns.Clear();
            dgvAccounts.Rows.Clear();

            dgvAccounts.Columns.Add("Owner", "Owner Name");
            dgvAccounts.Columns.Add("AccountNumber", "Account ID");
            dgvAccounts.Columns.Add("Balance", "Balance (FCFA)");

            dgvAccounts.ReadOnly = true;
            dgvAccounts.AllowUserToAddRows = false;
            dgvAccounts.MultiSelect = false;
            dgvAccounts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAccounts.RowHeadersVisible = false;
            dgvAccounts.AllowUserToResizeRows = false;

            // Royal Navy & Gold styling for table
            dgvAccounts.BackgroundColor = Color.FromArgb(17, 34, 64);
            dgvAccounts.GridColor = Color.FromArgb(30, 50, 80);
            dgvAccounts.BorderStyle = BorderStyle.None;
            dgvAccounts.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvAccounts.EnableHeadersVisualStyles = false;
            dgvAccounts.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvAccounts.ColumnHeadersHeight = 38;
            dgvAccounts.RowTemplate.Height = 34;

            dgvAccounts.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(10, 22, 42);
            dgvAccounts.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(212, 175, 55);
            dgvAccounts.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            dgvAccounts.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.FromArgb(10, 22, 42);
            dgvAccounts.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.FromArgb(212, 175, 55);

            dgvAccounts.DefaultCellStyle.BackColor = Color.FromArgb(17, 34, 64);
            dgvAccounts.DefaultCellStyle.ForeColor = Color.FromArgb(226, 232, 240);
            dgvAccounts.DefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);
            dgvAccounts.DefaultCellStyle.SelectionBackColor = Color.FromArgb(35, 60, 95);
            dgvAccounts.DefaultCellStyle.SelectionForeColor = Color.FromArgb(255, 215, 0);

            dgvAccounts.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(23, 44, 75);
            dgvAccounts.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(226, 232, 240);
            dgvAccounts.AlternatingRowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(35, 60, 95);
            dgvAccounts.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.FromArgb(255, 215, 0);
        }

        private void LoadInitialData()
        {
            // Initial data matching original lab data
            accounts.Add(new BankAccount("ELOMBA", GenerateAccountNumber(), 250000));
            accounts.Add(new BankAccount("BARKA", GenerateAccountNumber(), 355740));
            accounts.Add(new BankAccount("ARINATA", GenerateAccountNumber(), 125000));
            DisplayAccounts();
        }

        private string GenerateAccountNumber()
        {
            string number;
            do
            {
                number = "DE-" + random.Next(100000, 1000000).ToString();
            }
            while (accounts.Exists(a => a.AccountNumber == number));

            return number;
        }

        private void DisplayAccounts()
        {
            dgvAccounts.Rows.Clear();

            foreach (BankAccount account in accounts)
            {
                int rowIndex = dgvAccounts.Rows.Add(
                    account.Owner,
                    account.AccountNumber,
                    account.Balance.ToString("N0")
                );

                dgvAccounts.Rows[rowIndex].Tag = account;
            }
        }

        private void btnCreateAccount_Click(object? sender, EventArgs e)
        {
            string owner = txtOwner.Text.Trim();
            decimal amount = numAmount.Value;

            if (string.IsNullOrWhiteSpace(owner))
            {
                MessageBox.Show("Please enter the account owner's name.");
                txtOwner.Focus();
                return;
            }

            if (amount < 0)
            {
                MessageBox.Show("The initial balance cannot be negative.");
                return;
            }

            string accountNumber = GenerateAccountNumber();
            BankAccount account = new BankAccount(owner, accountNumber, amount);

            accounts.Add(account);
            DisplayAccounts();

            MessageBox.Show(
                "Account created successfully!\n" +
                "Account Number: " + accountNumber
            );

            txtOwner.Clear();
            numAmount.Value = 0;
        }

        private BankAccount? GetSelectedAccount()
        {
            if (dgvAccounts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an account from the table.");
                return null;
            }

            return dgvAccounts.SelectedRows[0].Tag as BankAccount;
        }

        private void btnDeposit_Click(object? sender, EventArgs e)
        {
            BankAccount? account = GetSelectedAccount();
            if (account == null) return;

            decimal amount = numAmount.Value;
            if (amount <= 0)
            {
                MessageBox.Show("Enter a deposit amount greater than zero.");
                return;
            }

            account.Deposit(amount);
            DisplayAccounts();

            MessageBox.Show(
                "Deposit successful!\nNew balance: " +
                account.Balance.ToString("N0") + " FCFA"
            );
        }

        private void btnWithdraw_Click(object? sender, EventArgs e)
        {
            BankAccount? account = GetSelectedAccount();
            if (account == null) return;

            decimal amount = numAmount.Value;
            if (amount <= 0)
            {
                MessageBox.Show("Enter a withdrawal amount greater than zero.");
                return;
            }

            if (amount > account.Balance)
            {
                MessageBox.Show("Insufficient balance!");
                return;
            }

            account.Withdraw(amount);
            DisplayAccounts();

            MessageBox.Show(
                "Withdrawal successful!\nNew balance: " +
                account.Balance.ToString("N0") + " FCFA"
            );
        }

        private void InitializeComponent()
        {
            // Container & Decorative Controls
            pnlHeader = new Panel();
            lblHeaderTitle = new Label();
            lblHeaderSubtitle = new Label();
            pnlGoldStripe = new Panel();

            pnlLeftCard = new Panel();
            lblLeftCardTitle = new Label();
            lblOwner = new Label();
            txtOwner = new TextBox();
            btnCreateAccount = new Button();
            pnlDivider = new Panel();
            lblTransactionsTitle = new Label();
            lblAmount = new Label();
            numAmount = new NumericUpDown();
            lblInstruction = new Label();

            pnlRightCard = new Panel();
            lblTableTitle = new Label();
            dgvAccounts = new DataGridView();
            btnDeposit = new Button();
            btnWithdraw = new Button();

            ((System.ComponentModel.ISupportInitialize)numAmount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).BeginInit();
            pnlHeader.SuspendLayout();
            pnlLeftCard.SuspendLayout();
            pnlRightCard.SuspendLayout();
            SuspendLayout();

            // 
            // pnlHeader: Royal Deep Navy Header Banner
            // 
            pnlHeader.BackColor = Color.FromArgb(10, 22, 42);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Height = 72;
            pnlHeader.Controls.Add(lblHeaderTitle);
            pnlHeader.Controls.Add(lblHeaderSubtitle);

            // 
            // lblHeaderTitle: Champagne Gold Branding
            // 
            lblHeaderTitle.AutoSize = true;
            lblHeaderTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblHeaderTitle.ForeColor = Color.FromArgb(212, 175, 55);
            lblHeaderTitle.Location = new Point(24, 12);
            lblHeaderTitle.Name = "lblHeaderTitle";
            lblHeaderTitle.Text = "✦ BARKA FIRST BANK";

            // 
            // lblHeaderSubtitle
            // 
            lblHeaderSubtitle.AutoSize = true;
            lblHeaderSubtitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Regular);
            lblHeaderSubtitle.ForeColor = Color.FromArgb(145, 162, 185);
            lblHeaderSubtitle.Location = new Point(26, 44);
            lblHeaderSubtitle.Name = "lblHeaderSubtitle";
            lblHeaderSubtitle.Text = "PREMIER SUBSCRIBER MANAGEMENT SYSTEM";

            // 
            // pnlGoldStripe: Champagne Gold Accent Strip
            // 
            pnlGoldStripe.BackColor = Color.FromArgb(212, 175, 55);
            pnlGoldStripe.Dock = DockStyle.Top;
            pnlGoldStripe.Height = 3;

            // 
            // pnlLeftCard: Left Elevation Card for Inputs
            // 
            pnlLeftCard.BackColor = Color.FromArgb(17, 34, 64);
            pnlLeftCard.Location = new Point(24, 92);
            pnlLeftCard.Size = new Size(316, 368);
            pnlLeftCard.Name = "pnlLeftCard";
            pnlLeftCard.Paint += (s, e) =>
            {
                ControlPaint.DrawBorder(e.Graphics, pnlLeftCard.ClientRectangle, Color.FromArgb(35, 55, 90), ButtonBorderStyle.Solid);
            };
            pnlLeftCard.Controls.Add(lblLeftCardTitle);
            pnlLeftCard.Controls.Add(lblOwner);
            pnlLeftCard.Controls.Add(txtOwner);
            pnlLeftCard.Controls.Add(btnCreateAccount);
            pnlLeftCard.Controls.Add(pnlDivider);
            pnlLeftCard.Controls.Add(lblTransactionsTitle);
            pnlLeftCard.Controls.Add(lblAmount);
            pnlLeftCard.Controls.Add(numAmount);
            pnlLeftCard.Controls.Add(lblInstruction);

            // 
            // lblLeftCardTitle
            // 
            lblLeftCardTitle.AutoSize = true;
            lblLeftCardTitle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblLeftCardTitle.ForeColor = Color.FromArgb(212, 175, 55);
            lblLeftCardTitle.Location = new Point(18, 16);
            lblLeftCardTitle.Name = "lblLeftCardTitle";
            lblLeftCardTitle.Text = "✦ ACCOUNT REGISTRATION";

            // 
            // lblOwner
            // 
            lblOwner.AutoSize = true;
            lblOwner.Font = new Font("Segoe UI", 9F);
            lblOwner.ForeColor = Color.FromArgb(204, 214, 246);
            lblOwner.Location = new Point(18, 45);
            lblOwner.Name = "lblOwner";
            lblOwner.Text = "Account Owner Name:";

            // 
            // txtOwner
            // 
            txtOwner.BackColor = Color.FromArgb(24, 45, 75);
            txtOwner.BorderStyle = BorderStyle.FixedSingle;
            txtOwner.Font = new Font("Segoe UI", 10F);
            txtOwner.ForeColor = Color.White;
            txtOwner.Location = new Point(18, 68);
            txtOwner.Name = "txtOwner";
            txtOwner.Size = new Size(278, 30);
            txtOwner.TabIndex = 0;

            // 
            // btnCreateAccount
            // 
            btnCreateAccount.BackColor = Color.FromArgb(212, 175, 55);
            btnCreateAccount.Cursor = Cursors.Hand;
            btnCreateAccount.FlatAppearance.BorderSize = 0;
            btnCreateAccount.FlatAppearance.MouseOverBackColor = Color.FromArgb(235, 195, 75);
            btnCreateAccount.FlatAppearance.MouseDownBackColor = Color.FromArgb(185, 150, 40);
            btnCreateAccount.FlatStyle = FlatStyle.Flat;
            btnCreateAccount.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnCreateAccount.ForeColor = Color.FromArgb(10, 25, 47);
            btnCreateAccount.Location = new Point(18, 108);
            btnCreateAccount.Name = "btnCreateAccount";
            btnCreateAccount.Size = new Size(278, 36);
            btnCreateAccount.TabIndex = 1;
            btnCreateAccount.Text = "+ CREATE ACCOUNT";
            btnCreateAccount.UseVisualStyleBackColor = false;

            // 
            // pnlDivider
            // 
            pnlDivider.BackColor = Color.FromArgb(35, 55, 90);
            pnlDivider.Location = new Point(18, 160);
            pnlDivider.Name = "pnlDivider";
            pnlDivider.Size = new Size(278, 1);

            // 
            // lblTransactionsTitle
            // 
            lblTransactionsTitle.AutoSize = true;
            lblTransactionsTitle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblTransactionsTitle.ForeColor = Color.FromArgb(212, 175, 55);
            lblTransactionsTitle.Location = new Point(18, 178);
            lblTransactionsTitle.Name = "lblTransactionsTitle";
            lblTransactionsTitle.Text = "✦ FUNDS TRANSACTION";

            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.Font = new Font("Segoe UI", 9F);
            lblAmount.ForeColor = Color.FromArgb(204, 214, 246);
            lblAmount.Location = new Point(18, 207);
            lblAmount.Name = "lblAmount";
            lblAmount.Text = "Transaction Amount (FCFA):";

            // 
            // numAmount
            // 
            numAmount.BackColor = Color.FromArgb(24, 45, 75);
            numAmount.BorderStyle = BorderStyle.FixedSingle;
            numAmount.Font = new Font("Segoe UI", 10F);
            numAmount.ForeColor = Color.White;
            numAmount.Location = new Point(18, 230);
            numAmount.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            numAmount.ThousandsSeparator = true;
            numAmount.Name = "numAmount";
            numAmount.Size = new Size(278, 30);
            numAmount.TabIndex = 2;

            // 
            // lblInstruction
            // 
            lblInstruction.Font = new Font("Segoe UI", 8.2F, FontStyle.Italic);
            lblInstruction.ForeColor = Color.FromArgb(136, 153, 178);
            lblInstruction.Location = new Point(18, 275);
            lblInstruction.Name = "lblInstruction";
            lblInstruction.Size = new Size(278, 70);
            lblInstruction.Text = "Tip: Select an account in the right table, enter the desired amount above, and click Deposit or Withdraw.";

            // 
            // pnlRightCard: Right Elevation Card for Grid and Operations
            // 
            pnlRightCard.BackColor = Color.FromArgb(17, 34, 64);
            pnlRightCard.Location = new Point(360, 92);
            pnlRightCard.Size = new Size(570, 368);
            pnlRightCard.Name = "pnlRightCard";
            pnlRightCard.Paint += (s, e) =>
            {
                ControlPaint.DrawBorder(e.Graphics, pnlRightCard.ClientRectangle, Color.FromArgb(35, 55, 90), ButtonBorderStyle.Solid);
            };
            pnlRightCard.Controls.Add(lblTableTitle);
            pnlRightCard.Controls.Add(dgvAccounts);
            pnlRightCard.Controls.Add(btnDeposit);
            pnlRightCard.Controls.Add(btnWithdraw);

            // 
            // lblTableTitle
            // 
            lblTableTitle.AutoSize = true;
            lblTableTitle.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblTableTitle.ForeColor = Color.FromArgb(212, 175, 55);
            lblTableTitle.Location = new Point(18, 16);
            lblTableTitle.Name = "lblTableTitle";
            lblTableTitle.Text = "✦ ACTIVE SUBSCRIBER ACCOUNTS";

            // 
            // dgvAccounts
            // 
            dgvAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvAccounts.Location = new Point(18, 42);
            dgvAccounts.Name = "dgvAccounts";
            dgvAccounts.Size = new Size(534, 248);
            dgvAccounts.TabIndex = 3;

            // 
            // btnDeposit: Emerald Green Action Button
            // 
            btnDeposit.BackColor = Color.FromArgb(16, 149, 106);
            btnDeposit.Cursor = Cursors.Hand;
            btnDeposit.FlatAppearance.BorderSize = 0;
            btnDeposit.FlatAppearance.MouseOverBackColor = Color.FromArgb(20, 180, 130);
            btnDeposit.FlatAppearance.MouseDownBackColor = Color.FromArgb(12, 120, 85);
            btnDeposit.FlatStyle = FlatStyle.Flat;
            btnDeposit.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnDeposit.ForeColor = Color.White;
            btnDeposit.Location = new Point(18, 305);
            btnDeposit.Name = "btnDeposit";
            btnDeposit.Size = new Size(257, 44);
            btnDeposit.TabIndex = 4;
            btnDeposit.Text = "↓   DEPOSIT";
            btnDeposit.UseVisualStyleBackColor = false;

            // 
            // btnWithdraw: Crimson Wine Action Button
            // 
            btnWithdraw.BackColor = Color.FromArgb(185, 45, 65);
            btnWithdraw.Cursor = Cursors.Hand;
            btnWithdraw.FlatAppearance.BorderSize = 0;
            btnWithdraw.FlatAppearance.MouseOverBackColor = Color.FromArgb(215, 60, 85);
            btnWithdraw.FlatAppearance.MouseDownBackColor = Color.FromArgb(150, 30, 50);
            btnWithdraw.FlatStyle = FlatStyle.Flat;
            btnWithdraw.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            btnWithdraw.ForeColor = Color.White;
            btnWithdraw.Location = new Point(295, 305);
            btnWithdraw.Name = "btnWithdraw";
            btnWithdraw.Size = new Size(257, 44);
            btnWithdraw.TabIndex = 5;
            btnWithdraw.Text = "↑   WITHDRAW";
            btnWithdraw.UseVisualStyleBackColor = false;

            // 
            // Form1
            // 
            BackColor = Color.FromArgb(10, 25, 47);
            ClientSize = new Size(956, 484);
            Controls.Add(pnlRightCard);
            Controls.Add(pnlLeftCard);
            Controls.Add(pnlGoldStripe);
            Controls.Add(pnlHeader);
            Font = new Font("Segoe UI", 9F);
            ForeColor = Color.FromArgb(226, 232, 240);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "BARKA FIRST BANK SUBSCRIBERS";

            ((System.ComponentModel.ISupportInitialize)numAmount).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).EndInit();
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            pnlLeftCard.ResumeLayout(false);
            pnlLeftCard.PerformLayout();
            pnlRightCard.ResumeLayout(false);
            pnlRightCard.PerformLayout();
            ResumeLayout(false);
        }
    }
}