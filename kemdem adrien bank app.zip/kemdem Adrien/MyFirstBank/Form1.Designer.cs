﻿using System;

namespace BankManagementApp
{
    public class BankAccount
    {
        public string Owner { get; set; }
        public string AccountNumber { get; set; }
        public decimal Balance { get; set; }

        public BankAccount(string owner, string accountNumber, decimal balance)
        {
            Owner = owner;
            AccountNumber = accountNumber;
            Balance = balance;
        }

        public void Deposit(decimal amount)
        {
            if (amount > 0)
                Balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount > 0 && amount <= Balance)
                Balance -= amount;
        }
    }
}