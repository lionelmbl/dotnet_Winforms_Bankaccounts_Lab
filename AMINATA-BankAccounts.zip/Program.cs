namespace BankManagementApp
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            var form = new Form1();
            if (Environment.GetCommandLineArgs().Contains("--preview"))
            {
                form.Shown += (_, _) =>
                {
                    using var bitmap = new System.Drawing.Bitmap(form.Width, form.Height);
                    form.DrawToBitmap(bitmap, new System.Drawing.Rectangle(0, 0, form.Width, form.Height));
                    bitmap.Save(System.IO.Path.Combine(AppContext.BaseDirectory, "app-preview.png"));
                };
            }
            Application.Run(form);
        }
    }
}
