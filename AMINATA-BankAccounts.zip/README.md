# AMINATA - My First Bank

Windows Forms bank account management application with a navy, teal and gold dashboard.

## Run
Requires Windows and .NET SDK 10.0.400 (or a compatible patch).

    dotnet run --project MyFirstBank.csproj

Create accounts, select an account, then enter an amount to deposit or withdraw.
Balances and account counts update automatically. Data is held in memory for the current session.

The included app-preview.png shows the application.
