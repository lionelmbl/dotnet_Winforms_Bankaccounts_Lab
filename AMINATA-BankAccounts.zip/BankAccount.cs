﻿using System;

namespace BankManagementApp
{
    public class BankAccount
    {
        public string Owner { get; }
        public string AccountNumber { get; }
        public decimal Balance { get; private set; }

        public BankAccount(string owner, string accountNumber, decimal balance)
        {
            if (string.IsNullOrWhiteSpace(owner))
                throw new ArgumentException("An owner is required.", nameof(owner));
            if (string.IsNullOrWhiteSpace(accountNumber))
                throw new ArgumentException("An account number is required.", nameof(accountNumber));
            if (balance < 0)
                throw new ArgumentOutOfRangeException(nameof(balance));
            Owner = owner.Trim();
            AccountNumber = accountNumber;
            Balance = balance;
        }

        public void Deposit(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(nameof(amount));
            Balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(nameof(amount));
            if (amount > Balance)
                throw new InvalidOperationException("Insufficient balance.");
            Balance -= amount;
        }
    }
}
