using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace BankManagementApp
{
    public partial class Form1 : Form
    {
        private readonly List<BankAccount> accounts = new List<BankAccount>();
        private readonly Random random = new Random();

        // Controls
        private Label lblOwner;
        private TextBox txtOwner;
        private Label lblAmount;
        private NumericUpDown numAmount;
        private Button btnCreateAccount;
        private DataGridView dgvAccounts;
        private Button btnDeposit;
        private Button btnWithdraw;

        public Form1()
        {
            InitializeComponent();
            SetupTable();
            LoadInitialData();

            // Connect the buttons to their event handlers.
            btnCreateAccount.Click += btnCreateAccount_Click;
            btnDeposit.Click += btnDeposit_Click;
            btnWithdraw.Click += btnWithdraw_Click;
        }

        private void SetupTable()
        {
            dgvAccounts.Columns.Clear();
            dgvAccounts.Rows.Clear();

            dgvAccounts.Columns.Add("Owner", "Owner");
            dgvAccounts.Columns.Add("AccountNumber", "Account Number");
            dgvAccounts.Columns.Add("Balance", "Amount (FCFA)");

            dgvAccounts.ReadOnly = true;
            dgvAccounts.AllowUserToAddRows = false;
            dgvAccounts.AllowUserToDeleteRows = false;
            dgvAccounts.RowHeadersVisible = false;
            dgvAccounts.MultiSelect = false;
            dgvAccounts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAccounts.Columns["Balance"].DefaultCellStyle.Format = "N0";
            dgvAccounts.Columns["Balance"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }

        private void LoadInitialData()
        {
            // Initial data matching the lab board notes
            accounts.Add(new BankAccount("ELOMBA", GenerateAccountNumber(), 250000));
            accounts.Add(new BankAccount("BARKA", GenerateAccountNumber(), 355740));
            accounts.Add(new BankAccount("ARINATA", GenerateAccountNumber(), 125000));
            DisplayAccounts();
        }

        private string GenerateAccountNumber()
        {
            string number;
            do
            {
                number = "DE-" + random.Next(100000, 1000000).ToString();
            }
            while (accounts.Exists(a => a.AccountNumber == number));

            return number;
        }

        private void DisplayAccounts(BankAccount selectedAccount = null)
        {
            selectedAccount ??= dgvAccounts.CurrentRow?.Tag as BankAccount;
            dgvAccounts.Rows.Clear();
            decimal total = 0;
            foreach (var item in accounts) total += item.Balance;
            totalBalance.Text = total.ToString("N0") + " FCFA";
            accountCount.Text = accounts.Count.ToString("00");

            foreach (BankAccount account in accounts)
            {
                int rowIndex = dgvAccounts.Rows.Add(
                    account.Owner,
                    account.AccountNumber,
                    account.Balance
                );

                dgvAccounts.Rows[rowIndex].Tag = account;
                if (account == selectedAccount)
                    dgvAccounts.CurrentCell = dgvAccounts.Rows[rowIndex].Cells[0];
            }
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            string owner = txtOwner.Text.Trim();
            decimal amount = numAmount.Value;

            if (string.IsNullOrWhiteSpace(owner))
            {
                MessageBox.Show("Please enter the account owner's name.");
                txtOwner.Focus();
                return;
            }

            if (amount < 0)
            {
                MessageBox.Show("The initial balance cannot be negative.");
                return;
            }

            string accountNumber = GenerateAccountNumber();
            BankAccount account = new BankAccount(owner, accountNumber, amount);

            accounts.Add(account);
            DisplayAccounts(account);

            MessageBox.Show(
                "Account created successfully!\n" +
                "Account Number: " + accountNumber
            );

            txtOwner.Clear();
            numAmount.Value = 0;
        }

        private BankAccount GetSelectedAccount()
        {
            if (dgvAccounts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an account from the table.");
                return null;
            }

            return dgvAccounts.SelectedRows[0].Tag as BankAccount;
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();
            if (account == null) return;

            decimal amount = numAmount.Value;
            if (amount <= 0)
            {
                MessageBox.Show("Enter a deposit amount greater than zero.");
                return;
            }

            account.Deposit(amount);
            DisplayAccounts(account);

            MessageBox.Show(
                "Deposit successful!\nNew balance: " +
                account.Balance.ToString("N0") + " FCFA"
            );
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();
            if (account == null) return;

            decimal amount = numAmount.Value;
            if (amount <= 0)
            {
                MessageBox.Show("Enter a withdrawal amount greater than zero.");
                return;
            }

            if (amount > account.Balance)
            {
                MessageBox.Show("Insufficient balance!");
                return;
            }

            account.Withdraw(amount);
            DisplayAccounts(account);

            MessageBox.Show(
                "Withdrawal successful!\nNew balance: " +
                account.Balance.ToString("N0") + " FCFA"
            );
        }

        private Label totalBalance;
        private Label accountCount;

        private Label MakeLabel(Control parent, string text, int x, int y, int size, Color color, bool bold = false)
        {
            var label = new Label { Text = text, Location = new Point(x, y), AutoSize = true,
                ForeColor = color, Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular) };
            parent.Controls.Add(label);
            return label;
        }

        private void StyleButton(Button button, string text, Color background, Color foreground, int x, int y, int width)
        {
            button.Text = text;
            button.SetBounds(x, y, width, 44);
            button.BackColor = background;
            button.ForeColor = foreground;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            button.Cursor = Cursors.Hand;
            button.UseVisualStyleBackColor = false;
        }

        private void InitializeComponent()
        {
            Color navy = Color.FromArgb(19, 37, 61);
            Color teal = Color.FromArgb(0, 125, 128);
            Color muted = Color.FromArgb(103, 119, 137);
            Color gold = Color.FromArgb(242, 186, 79);
            SuspendLayout();
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoScaleDimensions = new SizeF(96, 96);
            ClientSize = new Size(1080, 710);
            Font = new Font("Segoe UI", 10, FontStyle.Regular);
            BackColor = Color.FromArgb(241, 245, 249);
            ForeColor = navy;
            Text = "AMINATA | My First Bank";
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            var header = new Panel { BackColor = navy, Dock = DockStyle.Top, Height = 108 };
            Controls.Add(header);
            MakeLabel(header, "AMINATA", 30, 19, 23, Color.White, true);
            MakeLabel(header, "MY FIRST BANK  /  ACCOUNT MANAGEMENT", 32, 66, 9, Color.FromArgb(163, 185, 208));
            MakeLabel(header, "BANKING WORKSPACE", 839, 30, 10, gold, true);
            MakeLabel(header, "Your accounts, at a glance", 839, 56, 9, Color.White);

            MakeLabel(this, "Account overview", 30, 128, 19, navy, true);
            MakeLabel(this, "Manage balances and everyday transactions in one place.", 32, 166, 10, muted);

            var balanceCard = new Panel { BackColor = teal, Location = new Point(30, 204), Size = new Size(660, 112) };
            Controls.Add(balanceCard);
            MakeLabel(balanceCard, "TOTAL BALANCE", 22, 14, 9, Color.FromArgb(190, 233, 230), true);
            totalBalance = MakeLabel(balanceCard, "0 FCFA", 20, 40, 25, Color.White, true);
            var countCard = new Panel { BackColor = navy, Location = new Point(710, 204), Size = new Size(340, 112) };
            Controls.Add(countCard);
            MakeLabel(countCard, "ACTIVE ACCOUNTS", 22, 14, 9, Color.FromArgb(163, 185, 208), true);
            accountCount = MakeLabel(countCard, "0", 20, 40, 25, gold, true);

            var entry = new Panel { BackColor = Color.White, Location = new Point(30, 338), Size = new Size(300, 316) };
            Controls.Add(entry);
            MakeLabel(entry, "New account", 20, 16, 15, navy, true);
            lblOwner = MakeLabel(entry, "Account owner", 20, 59, 10, muted);
            txtOwner = new TextBox { Name = "txtOwner", Location = new Point(20, 85), Size = new Size(260, 30), MaxLength = 100, PlaceholderText = "Enter owner's name", TabIndex = 0 };
            entry.Controls.Add(txtOwner);
            lblAmount = MakeLabel(entry, "Amount (FCFA)", 20, 130, 10, muted);
            numAmount = new NumericUpDown { Name = "numAmount", Location = new Point(20, 156), Size = new Size(260, 30), Maximum = 10000000, ThousandsSeparator = true, TabIndex = 1 };
            entry.Controls.Add(numAmount);
            MakeLabel(entry, "Used for opening balance or transaction.", 20, 197, 9, muted);
            btnCreateAccount = new Button { Name = "btnCreateAccount", TabIndex = 2 };
            StyleButton(btnCreateAccount, "+  Create account", teal, Color.White, 20, 247, 260);
            entry.Controls.Add(btnCreateAccount);

            var ledger = new Panel { BackColor = Color.White, Location = new Point(350, 338), Size = new Size(700, 316) };
            Controls.Add(ledger);
            MakeLabel(ledger, "Account directory", 20, 16, 15, navy, true);
            MakeLabel(ledger, "Select an account, enter an amount, then choose an action.", 20, 51, 9, muted);
            dgvAccounts = new DataGridView { Name = "dgvAccounts", Location = new Point(20, 83), Size = new Size(660, 151),
                BackgroundColor = Color.White, BorderStyle = BorderStyle.None, CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                GridColor = Color.FromArgb(231, 237, 243), EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 36, ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                AllowUserToResizeRows = false, TabIndex = 3 };
            dgvAccounts.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(235, 242, 247), ForeColor = muted, Font = new Font("Segoe UI", 9, FontStyle.Bold), Padding = new Padding(8, 0, 8, 0), SelectionBackColor = Color.FromArgb(235, 242, 247), SelectionForeColor = muted };
            dgvAccounts.DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.White, ForeColor = navy, SelectionBackColor = Color.FromArgb(215, 241, 238), SelectionForeColor = navy, Padding = new Padding(8, 0, 8, 0), Font = new Font("Segoe UI", 10, FontStyle.Regular) };
            dgvAccounts.RowTemplate.Height = 37;
            ledger.Controls.Add(dgvAccounts);
            btnDeposit = new Button { Name = "btnDeposit", TabIndex = 4 };
            btnWithdraw = new Button { Name = "btnWithdraw", TabIndex = 5 };
            StyleButton(btnDeposit, "+  Deposit", teal, Color.White, 20, 247, 320);
            StyleButton(btnWithdraw, "-  Withdraw", gold, navy, 360, 247, 320);
            ledger.Controls.Add(btnDeposit);
            ledger.Controls.Add(btnWithdraw);
            MakeLabel(this, "MY FIRST BANK", 30, 674, 9, muted, true);
            MakeLabel(this, "Demo workspace  |  Data is kept for this session only", 696, 674, 9, muted);
            AcceptButton = btnCreateAccount;
            ResumeLayout(false);
            PerformLayout();
        }
    }
}


