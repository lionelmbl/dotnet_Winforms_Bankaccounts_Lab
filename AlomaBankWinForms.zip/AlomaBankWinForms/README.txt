ALOMA FIRST BANK - WinForms lab (C#, Visual Studio)
====================================================
Lab: Create a WinForm app for bank accounts management (OOP + WinForms).
Hint applied: the app uses a BankAccount class.

How to open and run
-------------------
1. Unzip AlomaBankWinForms.zip
2. Double-click AlomaBankWinForms.sln (opens in Visual Studio)
3. Press F5 (or Ctrl+F5 to run without debugging)

To edit the window visually: in Solution Explorer, double-click MainForm.cs
(it opens in the Designer). Press F7 to see the code, Shift+F7 to go back.

If Visual Studio says ".NET 10 is not supported": open AlomaBankWinForms.csproj
(double-click the project name) and change net10.0-windows to net8.0-windows.

Files
-----
AlomaBankWinForms.sln          Solution (double-click to open)
AlomaBankWinForms/
  AlomaBankWinForms.csproj     WinForms project (net10.0-windows)
  Program.cs                   Starts the application
  MainForm.cs                  Event handlers: Create account, Deposit, Withdraw
  MainForm.Designer.cs         The window layout (generated/edited by the Designer)
  MainForm.resx                Form resources
  BankAccount.cs               Owner, AccountNumber, Balance + Deposit/Withdraw
  InsufficientFundsException.cs  Custom exception (from the exceptions lab)

Controls (as on the board)
--------------------------
Form            Title "ALOMA FIRST BANK SUBSCRIBERS"
Label + TextBox Owner (typed text becomes UPPERCASE)
Button          CREATE ACCOUNT -> new account, random account number, balance 0
Label + NumericUpDown  Amount (steps of 1 000)
DataGridView    Owner | Account Number | Amount
                ELOMBA, BARKA, AMINATA are created directly in the code;
                their account numbers and amounts are generated randomly.
Buttons         Deposit / Withdraw on the selected row

How to use
----------
- Create: type a name in Owner, click CREATE ACCOUNT.
- Deposit / Withdraw: click a row in the grid, set Amount, click the button.

Tests to try
------------
Click CREATE ACCOUNT with Owner empty   -> warning, nothing created
Deposit 50 000 on ELOMBA               -> Amount increases by 50 000
Withdraw more than the balance          -> error box: Insufficient bank account balance
Deposit / Withdraw with Amount = 0      -> "Invalid amount" warning
