namespace AlomaBank
{
    // Custom exception (reused from the exceptions lab)
    public class InsufficientFundsException : Exception
    {
        private const string DefaultMessage = "Insufficient bank account balance";

        // Read-only properties
        public decimal Balance { get; }
        public decimal Requested { get; }

        public InsufficientFundsException()
            : base(DefaultMessage) { }

        public InsufficientFundsException(string message)
            : base(message) { }

        public InsufficientFundsException(string message, Exception inner)
            : base(message, inner) { }

        // Business constructor: stores the balance and the requested amount
        public InsufficientFundsException(decimal balance, decimal requested)
            : base(DefaultMessage)
        {
            Balance = balance;
            Requested = requested;
        }
    }
}
