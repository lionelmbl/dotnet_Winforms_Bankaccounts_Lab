namespace AlomaBank
{
    // The class suggested by the hint on the board: "Use a class BankAccount in your app"
    public class BankAccount
    {
        // These property names are used by the DataGridView columns (DataPropertyName)
        public string Owner { get; }
        public string AccountNumber { get; }
        public decimal Balance { get; private set; }   // shown in the "Amount" column

        public BankAccount(string owner, string accountNumber, decimal initialBalance)
        {
            if (string.IsNullOrWhiteSpace(owner))
                throw new ArgumentException("The owner name is required.", nameof(owner));
            if (initialBalance < 0)
                throw new ArgumentOutOfRangeException(nameof(initialBalance), "The initial balance cannot be negative.");

            Owner = owner.Trim();
            AccountNumber = accountNumber;
            Balance = initialBalance;
        }

        public void Deposit(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(nameof(amount), "The amount must be greater than 0.");

            Balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= 0)
                throw new ArgumentOutOfRangeException(nameof(amount), "The amount must be greater than 0.");

            if (amount > Balance)
                throw new InsufficientFundsException(Balance, amount);

            Balance -= amount;
        }

        // Random account number, e.g. 102-4581236-14
        public static string GenerateAccountNumber(Random rnd)
        {
            return $"{rnd.Next(100, 1000)}-{rnd.Next(1000000, 10000000)}-{rnd.Next(10, 100)}";
        }
    }
}
