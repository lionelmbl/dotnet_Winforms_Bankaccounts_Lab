using System.ComponentModel;

namespace AlomaBank
{
    public partial class MainForm : Form
    {
        private readonly Random rnd = new Random();

        // BindingList: the DataGridView updates automatically when an account is added
        private readonly BindingList<BankAccount> accounts = new BindingList<BankAccount>();

        public MainForm()
        {
            InitializeComponent();

            dgvAccounts.AutoGenerateColumns = false;   // we use the 3 columns defined in the Designer
            dgvAccounts.DataSource = accounts;

            SeedAccounts();
        }

        // Accounts "created directly in the code", with account numbers and amounts "generated randomly"
        private void SeedAccounts()
        {
            string[] owners = { "ELOMBA", "BARKA", "AMINATA" };

            foreach (string owner in owners)
            {
                accounts.Add(new BankAccount(owner, NewAccountNumber(), rnd.Next(100000, 500001)));
            }
        }

        // Generates an account number that is not already used
        private string NewAccountNumber()
        {
            string number;
            do
            {
                number = BankAccount.GenerateAccountNumber(rnd);
            }
            while (accounts.Any(a => a.AccountNumber == number));

            return number;
        }

        // Returns the account of the selected row, or null (with a message) if none is selected
        private BankAccount GetSelectedAccount()
        {
            BankAccount account = dgvAccounts.CurrentRow?.DataBoundItem as BankAccount;
            if (account == null)
            {
                MessageBox.Show("Please select an account in the list.", "No account selected",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            return account;
        }

        // Refreshes one row of the grid after its balance changed
        private void RefreshAccount(BankAccount account)
        {
            accounts.ResetItem(accounts.IndexOf(account));
        }

        // ---------- CREATE ACCOUNT ----------
        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            try
            {
                var account = new BankAccount(txtOwner.Text, NewAccountNumber(), 0);
                accounts.Add(account);

                // Select the new row so the user can deposit straight away
                dgvAccounts.CurrentCell = dgvAccounts.Rows[accounts.Count - 1].Cells[0];

                txtOwner.Clear();
                txtOwner.Focus();
            }
            catch (ArgumentException ex)   // empty owner name
            {
                MessageBox.Show(ex.Message, "Cannot create account",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtOwner.Focus();
            }
        }

        // ---------- DEPOSIT ----------
        private void btnDeposit_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();
            if (account == null) return;

            try
            {
                account.Deposit(nudAmount.Value);
                RefreshAccount(account);
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Invalid amount: it must be greater than 0.", "Deposit",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ---------- WITHDRAW ----------
        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            BankAccount account = GetSelectedAccount();
            if (account == null) return;

            try
            {
                account.Withdraw(nudAmount.Value);
                RefreshAccount(account);
            }
            catch (InsufficientFundsException ex)      // specific catch first
            {
                MessageBox.Show($"{ex.Message}\n\nBalance: {ex.Balance:N0}\nRequested: {ex.Requested:N0}",
                                "Withdraw", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Invalid amount: it must be greater than 0.", "Withdraw",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
