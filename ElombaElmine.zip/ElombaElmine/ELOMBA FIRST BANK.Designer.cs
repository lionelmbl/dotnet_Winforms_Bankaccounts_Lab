﻿namespace WinFormsApp1
{
    partial class ELOMBA_FIRST_BANK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtOwner = new TextBox();
            numAmount = new NumericUpDown();
            btnCreateAccount = new Button();
            button2 = new Button();
            button3 = new Button();
            dgvAccounts = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)numAmount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(73, 93);
            label1.Name = "label1";
            label1.Size = new Size(73, 25);
            label1.TabIndex = 0;
            label1.Text = "Owner :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(73, 365);
            label2.Name = "label2";
            label2.Size = new Size(91, 25);
            label2.TabIndex = 1;
            label2.Text = "Amount : ";
            // 
            // txtOwner
            // 
            txtOwner.Location = new Point(174, 93);
            txtOwner.Name = "txtOwner";
            txtOwner.Size = new Size(291, 31);
            txtOwner.TabIndex = 2;
            // 
            // numAmount
            // 
            numAmount.Location = new Point(197, 363);
            numAmount.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            numAmount.Name = "numAmount";
            numAmount.Size = new Size(232, 31);
            numAmount.TabIndex = 3;
            numAmount.Value = new decimal(new int[] { 100, 0, 0, 0 });
            // 
            // btnCreateAccount
            // 
            btnCreateAccount.Location = new Point(220, 141);
            btnCreateAccount.Name = "btnCreateAccount";
            btnCreateAccount.Size = new Size(227, 34);
            btnCreateAccount.TabIndex = 4;
            btnCreateAccount.Text = "Create Account";
            btnCreateAccount.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(130, 453);
            button2.Name = "button2";
            button2.Size = new Size(161, 34);
            button2.TabIndex = 5;
            button2.Text = "Deposit";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(341, 453);
            button3.Name = "button3";
            button3.Size = new Size(153, 34);
            button3.TabIndex = 6;
            button3.Text = "Withdraw";
            button3.UseVisualStyleBackColor = true;
            // 
            // dgvAccounts
            // 
            dgvAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAccounts.Location = new Point(498, 93);
            dgvAccounts.Name = "dgvAccounts";
            dgvAccounts.RowHeadersWidth = 62;
            dgvAccounts.Size = new Size(525, 338);
            dgvAccounts.TabIndex = 7;
            // 
            // ELOMBA_FIRST_BANK
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1105, 563);
            Controls.Add(dgvAccounts);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(btnCreateAccount);
            Controls.Add(numAmount);
            Controls.Add(txtOwner);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "ELOMBA_FIRST_BANK";
            Text = "ELOMBA_FIRST_BANK";
            ((System.ComponentModel.ISupportInitialize)numAmount).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtOwner;
        private NumericUpDown numAmount;
        private Button btnCreateAccount;
        private Button button2;
        private Button button3;
        private DataGridView dgvAccounts;
    }
}