﻿using FirstProject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class ELOMBA_FIRST_BANK : Form
    {
        //using bindinglist automatically updates the grid
        private BindingList<BankAccount> accounts = new BindingList<BankAccount>();
        public ELOMBA_FIRST_BANK()
        {
            InitializeComponent();
            //link the list of accounts to your data list
            dgvAccounts.DataSource = accounts;

            // --- HARDCODED ACCOUNTS (From your whiteboard sketch) ---
            // These will appear instantly when the application opens
            accounts.Add(new BankAccount("ELOMBA", 250000));
            accounts.Add(new BankAccount("BARKA", 355740));
            accounts.Add(new BankAccount("AMINATA", 125000));
           

            //wiring up buttons to match designer names
            btnCreateAccount.Click += btnCreateAccount_Click;
            button2.Click += btnDeposit_Click;
            button3.Click += btnWithdraw_Click;

        }

        // create account button click event handler
        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            string ownerName = txtOwner.Text.Trim();
            decimal initialAmount = numAmount.Value;

            if (string.IsNullOrEmpty(ownerName))
            {
                MessageBox.Show("Please enter an owner name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // Create the new account using your constructor
            BankAccount newAccount = new BankAccount(ownerName, initialAmount);

            // Add it to the list (the grid will update automatically!)
            accounts.Add(newAccount);

            // Clear the textbox for the next entry
            txtOwner.Clear();
            numAmount.Value = 0;

            MessageBox.Show($"Account created successfully!\nAccount Number: {newAccount.AccountNumber}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // create deposit button click event handler
        private void btnDeposit_Click(object sender, EventArgs e)
        {
            // Ensure a row is selected in the grid
            if (dgvAccounts.CurrentRow == null)
            {
                MessageBox.Show("Please select an account from the grid first.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Get the currently selected BankAccount object from the grid row
            BankAccount selectedAccount = (BankAccount)dgvAccounts.CurrentRow.DataBoundItem;
            decimal depositAmount = numAmount.Value;

            try
            {
                selectedAccount.Deposit(depositAmount);
                dgvAccounts.Refresh(); // Forces the grid to show the updated amount
                MessageBox.Show($"Deposited {depositAmount:C} successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 3. WITHDRAW BUTTON CLICK
        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            // Ensure a row is selected in the grid
            if (dgvAccounts.CurrentRow == null)
            {
                MessageBox.Show("Please select an account from the grid first.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Get the currently selected BankAccount object from the grid row
            BankAccount selectedAccount = (BankAccount)dgvAccounts.CurrentRow.DataBoundItem;
            decimal withdrawAmount = numAmount.Value;

            if (withdrawAmount <= 0)
            {
                MessageBox.Show("Withdrawal amount must be positive.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Use your class method that returns true/false
            bool success = selectedAccount.Withdraw(withdrawAmount);

            if (success)
            {
                dgvAccounts.Refresh(); // Forces the grid to show the updated amount
                MessageBox.Show($"Withdrew {withdrawAmount:C} successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Insufficient funds or invalid operation.", "Transaction Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
