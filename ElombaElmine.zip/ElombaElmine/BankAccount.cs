﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstProject
{
    public class BankAccount
    {
        //encapsulated fields
        public string Owner { get; set; }
        public string AccountNumber { get; set; }
        public decimal Amount { get; private set; } // private sets the amount to be modified only within the class

        //constructor
        public BankAccount(string owner, decimal initialDeposit)
        {
            Owner = owner;
            Amount = initialDeposit;
            AccountNumber = GenerateRandomAccountNumber();
        }

        //helper method to randomly generate an account number
        private string GenerateRandomAccountNumber()
        {
            Random rand = new Random();
            //generates a random 8 digit number for the account number
            return rand.Next(10000000, 99999999).ToString();
        }
        //OOP methods for deposit
        public void Deposit(decimal money)
        {
            if (money > 0)
            {
                Amount += money;
            }
            else
            {
                throw new ArgumentException("Deposit amount must be positive.");
            }
        }
        //OOP methods for withdraw
        public bool Withdraw(decimal money)
        {
            if (money > 0 && money <= Amount)
            {
                Amount -= money;
                return true;
            }
            else
            {
                return false; // withdrawal failed due to insufficient funds or invalid amount
            }
        }
    }
}
