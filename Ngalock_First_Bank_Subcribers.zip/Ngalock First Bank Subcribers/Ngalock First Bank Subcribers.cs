using System.ComponentModel;

namespace Ngalock_First_Bank_Subcribers;

/// <summary>
/// Main WinForms screen for the Ngalock First Bank Subscribers assignment.
/// </summary>
public sealed class Ngalock_First_Bank_Subcribers : Form
{
    private readonly TextBox txtOwner = new();
    private readonly NumericUpDown numericAmount = new();
    private readonly DataGridView dgvAccounts = new();
    private readonly BindingList<BankAccount> accounts = new();
    private readonly BindingSource bindingSource = new();

    private readonly Button btnCreate = new();
    private readonly Button btnDeposit = new();
    private readonly Button btnWithdraw = new();

    public Ngalock_First_Bank_Subcribers()
    {
        Text = "Ngalock First Bank Subcribers";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(900, 570);
        Size = new Size(1120, 650);
        Font = new Font("Segoe UI", 10F);
        BuildInterface();
        ConfigureAccountsGrid();
        ConnectEvents();
    }

    private void BuildInterface()
    {
        var group = new GroupBox
        {
            Text = "NGALOCK FIRST BANK SUBCRIBERS",
            Location = new Point(18, 18),
            Size = new Size(1065, 570),
            Anchor = AnchorStyles.Top | AnchorStyles.Bottom |
                     AnchorStyles.Left | AnchorStyles.Right,
            Padding = new Padding(12)
        };
        Controls.Add(group);

        group.Controls.Add(new Label
        {
            Text = "Owner:",
            Location = new Point(28, 75),
            Size = new Size(105, 32),
            Font = new Font(Font, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        });

        txtOwner.Name = "txtOwner";
        txtOwner.Location = new Point(145, 77);
        txtOwner.Size = new Size(255, 30);
        group.Controls.Add(txtOwner);

        btnCreate.Name = "btnCreate";
        btnCreate.Text = "CREATE ACCOUNT";
        btnCreate.Location = new Point(145, 122);
        btnCreate.Size = new Size(255, 42);
        group.Controls.Add(btnCreate);

        group.Controls.Add(new Label
        {
            Text = "Amount:",
            Location = new Point(28, 300),
            Size = new Size(105, 32),
            Font = new Font(Font, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        });

        numericAmount.Name = "numericAmount";
        numericAmount.DecimalPlaces = 2;
        numericAmount.Minimum = 0.01m;
        numericAmount.Maximum = 1_000_000_000m;
        numericAmount.Increment = 100m;
        numericAmount.Value = 100m;
        numericAmount.ThousandsSeparator = true;
        numericAmount.Location = new Point(145, 301);
        numericAmount.Size = new Size(255, 30);
        group.Controls.Add(numericAmount);

        dgvAccounts.Name = "dgvAccounts";
        dgvAccounts.Location = new Point(430, 48);
        dgvAccounts.Size = new Size(600, 300);
        dgvAccounts.Anchor = AnchorStyles.Top | AnchorStyles.Left |
                            AnchorStyles.Right;
        group.Controls.Add(dgvAccounts);

        btnDeposit.Name = "btnDeposit";
        btnDeposit.Text = "Deposit";
        btnDeposit.Location = new Point(460, 375);
        btnDeposit.Size = new Size(210, 44);
        group.Controls.Add(btnDeposit);

        btnWithdraw.Name = "btnWithdraw";
        btnWithdraw.Text = "Withdraw";
        btnWithdraw.Location = new Point(700, 375);
        btnWithdraw.Size = new Size(210, 44);
        group.Controls.Add(btnWithdraw);

        group.Controls.Add(new Label
        {
            Text = "Select an account in the table before depositing or withdrawing money.",
            Location = new Point(430, 435),
            Size = new Size(600, 45),
            ForeColor = SystemColors.ControlDarkDark
        });
    }

    private void ConfigureAccountsGrid()
    {
        dgvAccounts.AutoGenerateColumns = false;
        dgvAccounts.AllowUserToAddRows = false;
        dgvAccounts.AllowUserToDeleteRows = false;
        dgvAccounts.ReadOnly = true;
        dgvAccounts.MultiSelect = false;
        dgvAccounts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvAccounts.RowHeadersVisible = false;
        dgvAccounts.BackgroundColor = SystemColors.Window;

        dgvAccounts.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colOwner",
            HeaderText = "Owner",
            DataPropertyName = nameof(BankAccount.Owner),
            SortMode = DataGridViewColumnSortMode.NotSortable
        });
        dgvAccounts.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colAccountNumber",
            HeaderText = "Account Number",
            DataPropertyName = nameof(BankAccount.AccountNumber),
            SortMode = DataGridViewColumnSortMode.NotSortable
        });
        dgvAccounts.Columns.Add(new DataGridViewTextBoxColumn
        {
            Name = "colAmount",
            HeaderText = "Amount",
            DataPropertyName = nameof(BankAccount.Balance),
            DefaultCellStyle = new DataGridViewCellStyle { Format = "N2" },
            SortMode = DataGridViewColumnSortMode.NotSortable
        });

        bindingSource.DataSource = accounts;
        dgvAccounts.DataSource = bindingSource;
    }

    private void ConnectEvents()
    {
        btnCreate.Click += CreateAccount_Click;
        btnDeposit.Click += Deposit_Click;
        btnWithdraw.Click += Withdraw_Click;
    }

    private void CreateAccount_Click(object? sender, EventArgs e)
    {
        string owner = txtOwner.Text.Trim();

        if (string.IsNullOrWhiteSpace(owner))
        {
            MessageBox.Show("Please enter the account owner's name.",
                "Missing owner", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            txtOwner.Focus();
            return;
        }

        var account = new BankAccount(owner);
        accounts.Add(account);
        bindingSource.ResetBindings(false);

        MessageBox.Show(
            $"Account created successfully!{Environment.NewLine}Account Number: {account.AccountNumber}",
            "Account created", MessageBoxButtons.OK, MessageBoxIcon.Information);

        txtOwner.Clear();
        txtOwner.Focus();
    }

    private BankAccount? GetSelectedAccount()
    {
        if (dgvAccounts.CurrentRow?.DataBoundItem is BankAccount account)
            return account;

        MessageBox.Show("Please select an account in the table first.",
            "No account selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return null;
    }

    private void Deposit_Click(object? sender, EventArgs e)
    {
        BankAccount? account = GetSelectedAccount();
        if (account is null)
            return;

        try
        {
            account.Deposit(numericAmount.Value);
            bindingSource.ResetBindings(false);
            MessageBox.Show($"Deposit successful!{Environment.NewLine}New balance: {account.Balance:N2}",
                "Deposit", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (ArgumentException ex)
        {
            MessageBox.Show(ex.Message, "Invalid amount",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void Withdraw_Click(object? sender, EventArgs e)
    {
        BankAccount? account = GetSelectedAccount();
        if (account is null)
            return;

        try
        {
            account.Withdraw(numericAmount.Value);
            bindingSource.ResetBindings(false);
            MessageBox.Show($"Withdrawal successful!{Environment.NewLine}New balance: {account.Balance:N2}",
                "Withdrawal", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (ArgumentException ex)
        {
            MessageBox.Show(ex.Message, "Invalid amount",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        catch (InvalidOperationException ex)
        {
            MessageBox.Show(ex.Message, "Insufficient balance",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
