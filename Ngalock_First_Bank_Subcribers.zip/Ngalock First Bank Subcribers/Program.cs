namespace Ngalock_First_Bank_Subcribers;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new Ngalock_First_Bank_Subcribers());
    }
}
