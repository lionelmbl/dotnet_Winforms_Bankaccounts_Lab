# Ngalock First Bank Subcribers

C# Windows Forms bank-account management assignment, using the project and form name requested.

## Requirements
- Windows 10/11
- Visual Studio 2022 or newer
- .NET 10 SDK and the Visual Studio **.NET desktop development** workload

This project targets `net10.0-windows`, matching the .NET 10 SDK shown in the user's Visual Studio screenshot.

## Open and run
1. Extract the ZIP to a normal folder.
2. In Visual Studio, choose **File → Open → Project/Solution**.
3. Select `Ngalock First Bank Subcribers.csproj` from the extracted folder.
4. Wait for project load and package restore.
5. If needed, right-click the project in Solution Explorer and choose **Set as Startup Project**.
6. Press **F5** to run, or **Ctrl+F5** to run without debugging.

If the .NET 10 targeting pack is missing, use Visual Studio Installer to install the latest .NET desktop development components.

## Use the application
1. Type an account owner's name and click **CREATE ACCOUNT**.
2. Select the account's row in the table.
3. Enter an amount.
4. Click **Deposit** or **Withdraw**.
5. The Amount column updates; withdrawals above the current balance are rejected.

## OOP concepts
- `BankAccount` class and constructor
- Encapsulated balance
- Deposit and withdrawal methods with validation
- A collection of accounts displayed in a DataGridView

## Note
Accounts are stored in memory for this assignment and are cleared when the application closes. This is a learning/demo app, not production banking software.
