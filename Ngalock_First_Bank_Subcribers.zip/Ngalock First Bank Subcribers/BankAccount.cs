namespace Ngalock_First_Bank_Subcribers;

/// <summary>Represents a bank account and controls balance changes.</summary>
public sealed class BankAccount
{
    private static int _nextAccountNumber = 1;

    public string Owner { get; }
    public string AccountNumber { get; }
    public decimal Balance { get; private set; }

    public BankAccount(string owner)
    {
        if (string.IsNullOrWhiteSpace(owner))
            throw new ArgumentException("Enter the account owner's name.", nameof(owner));

        Owner = owner.Trim();
        AccountNumber = $"BA{_nextAccountNumber:D4}";
        _nextAccountNumber++;
        Balance = 0m;
    }

    public void Deposit(decimal amount)
    {
        if (amount <= 0)
            throw new ArgumentException("The amount must be greater than zero.");

        Balance += amount;
    }

    public void Withdraw(decimal amount)
    {
        if (amount <= 0)
            throw new ArgumentException("The amount must be greater than zero.");

        if (amount > Balance)
            throw new InvalidOperationException("Insufficient balance.");

        Balance -= amount;
    }
}
